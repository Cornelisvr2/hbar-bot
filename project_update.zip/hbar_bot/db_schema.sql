-- db_schema.sql
-- Wordt automatisch uitgevoerd bij eerste opstart van de Postgres-container
-- (via docker-entrypoint-initdb.d, zie docker-compose.yml)

CREATE TABLE IF NOT EXISTS sentiment_log (
    id SERIAL PRIMARY KEY,
    asset TEXT NOT NULL,                    -- 'BTC' of 'HBAR'
    headline TEXT NOT NULL,
    sentiment_score DOUBLE PRECISION NOT NULL,
    confidence DOUBLE PRECISION NOT NULL,
    is_idiosyncratic BOOLEAN NOT NULL,
    rationale TEXT,
    source TEXT DEFAULT 'llm',              -- 'llm' of 'vote_weighted' (welke engine)
    volatility_sigma DOUBLE PRECISION DEFAULT 0.5,  -- LLM-onzekerheidsscore (28 aug 2026, voor GBM-model)
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sentiment_log_asset_time
    ON sentiment_log (asset, created_at DESC);

CREATE TABLE IF NOT EXISTS strategy_signals (
    id SERIAL PRIMARY KEY,
    direction TEXT NOT NULL,                -- 'BUY', 'SELL', 'HOLD'
    confidence DOUBLE PRECISION NOT NULL,
    position_fraction DOUBLE PRECISION NOT NULL,
    btc_score DOUBLE PRECISION NOT NULL,
    hbar_score DOUBLE PRECISION NOT NULL,
    panic_override_triggered BOOLEAN DEFAULT FALSE,
    reasoning TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS trades (
    id SERIAL PRIMARY KEY,
    direction TEXT NOT NULL,                -- 'HBAR_TO_USDC' of 'USDC_TO_HBAR'
    engine TEXT NOT NULL,                   -- 'v1' of 'v2'
    network TEXT NOT NULL,                  -- 'testnet' of 'mainnet'
    amount_in DOUBLE PRECISION NOT NULL,
    estimated_amount_out DOUBLE PRECISION,
    actual_amount_out DOUBLE PRECISION,
    tx_hash TEXT,
    status TEXT NOT NULL,                   -- 'pending', 'success', 'failed'
    strategy_signal_id INTEGER REFERENCES strategy_signals(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_trades_created_at ON trades (created_at DESC);

CREATE TABLE IF NOT EXISTS open_positions (
    id SERIAL PRIMARY KEY,
    entry_price DOUBLE PRECISION NOT NULL,
    initial_stop_loss DOUBLE PRECISION,
    trailing_distance_pct DOUBLE PRECISION,
    highest_price_seen DOUBLE PRECISION NOT NULL,
    quantity_hbar DOUBLE PRECISION NOT NULL,
    trade_id INTEGER REFERENCES trades(id),
    is_open BOOLEAN NOT NULL DEFAULT TRUE,
    opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_open_positions_is_open ON open_positions (is_open);

-- Persistente LP-positie-staat (26 aug 2026): lost een kritieke bug op
-- waarbij de bot bij ELKE herstart (bv. de nachtelijke herkalibratie-
-- herstart) "vergat" dat er al een LP-positie open stond, omdat
-- LpManager.state.is_open puur in-memory was. Dit leidde tot meerdere,
-- gelijktijdig openstaande posities i.p.v. één beheerde positie. Slechts
-- EEN rij hoort hier ooit in te staan (de huidige, actieve positie, of
-- geen rij als er niets open staat).
CREATE TABLE IF NOT EXISTS active_lp_position (
    id SERIAL PRIMARY KEY,
    token_id BIGINT NOT NULL,
    tick_lower INTEGER NOT NULL,
    tick_upper INTEGER NOT NULL,
    opened_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Reflex-episode-logging (27 aug 2026): legt voor elke BULLISH_REFLEX/
-- BEARISH_REFLEX-episode de instap- en uitstapprijs vast, zodat we
-- achteraf kunnen beoordelen of de overstap daadwerkelijk nuttig was en
-- de drempels/trailing-stop op termijn kunnen bijstellen op basis van
-- echte, eigen historie.
CREATE TABLE IF NOT EXISTS reflex_episodes (
    id SERIAL PRIMARY KEY,
    regime TEXT NOT NULL,  -- 'bullish_reflex' of 'bearish_reflex'
    entry_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    entry_price DOUBLE PRECISION NOT NULL,
    entry_combined_score DOUBLE PRECISION NOT NULL,
    exit_at TIMESTAMPTZ,
    exit_price DOUBLE PRECISION,
    exit_reason TEXT,  -- 'trailing_stop', 'sentiment_reverted', of 'manual'
    return_pct DOUBLE PRECISION
);
CREATE INDEX IF NOT EXISTS idx_reflex_episodes_entry_at ON reflex_episodes(entry_at DESC);

-- Regimestatus-persistentie (27 aug 2026): lost een reeel, empirisch
-- waargenomen probleem op -- current_regime (LP_MODE/BULLISH_REFLEX/
-- BEARISH_REFLEX) werd bij ELKE herstart altijd teruggezet naar de
-- default LP_MODE, ongeacht de daadwerkelijke, laatst-bekende status.
-- Dit veroorzaakte een onterechte vangnet-poging (probeerde een
-- LP-positie te openen terwijl de bot legitiem in bullish_reflex zat
-- met kapitaal volledig in HBAR) en een misleidende "OVERGANG"-regel in
-- de reflex_episodes-logging. Net als active_lp_position: maximaal een
-- rij, wordt bij elke transitie overschreven.
CREATE TABLE IF NOT EXISTS bot_regime_state (
    id SERIAL PRIMARY KEY,
    current_regime TEXT NOT NULL,
    trailing_entry_price DOUBLE PRECISION,  -- alleen relevant tijdens BULLISH_REFLEX
    active_reflex_episode_id INTEGER,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Retention-policy (Gemini-feedback, 23 aug 2026): voorkomt dat de VPS-
-- schijf na weken volloopt met ruwe sentiment/signal-data. Wordt elke
-- nacht aangeroepen via recalibrate_cron.sh, NA de herkalibratie (die
-- heeft de recente data nog nodig).
CREATE OR REPLACE FUNCTION cleanup_old_data(retention_days INTEGER DEFAULT 30)
RETURNS TABLE(deleted_sentiment_rows BIGINT, deleted_signal_rows BIGINT) AS $$
DECLARE
    sentiment_count BIGINT;
    signal_count BIGINT;
BEGIN
    DELETE FROM sentiment_log WHERE created_at < now() - (retention_days || ' days')::interval;
    GET DIAGNOSTICS sentiment_count = ROW_COUNT;

    DELETE FROM strategy_signals WHERE created_at < now() - (retention_days || ' days')::interval;
    GET DIAGNOSTICS signal_count = ROW_COUNT;

    -- trades en open_positions NIET opschonen -- dat is de financiele
    -- historie, die blijft bewaard voor verantwoording/backtesting.

    RETURN QUERY SELECT sentiment_count, signal_count;
END;
$$ LANGUAGE plpgsql;
