"""
regime_orchestrator.py

Vervangt TradingOrchestrator + LpOrchestrator voor het SAMENGEVOEGDE
kapitaal (EUR 2.000) met een alles-of-niets regime-schakelaar:

- LP_MODE (rustig nieuws): volledige kapitaal in de HBAR/USDC V2-pool
- BULLISH_REFLEX (groot positief nieuws): pool leeghalen, alles naar HBAR
- BEARISH_REFLEX (groot negatief nieuws): pool leeghalen, alles naar USDC

Trigger: dezelfde vaste 40/60-weging als safety_override.py
(compute_fixed_combined_score), nu SYMMETRISCH toegepast -- niet alleen
als paniek-vangnet (alleen SELL forceren), maar ook als bullish-reflex
(BUY forceren). Dat is een bewuste afwijking van het eerdere principe
"een vangnet forceert nooit een koop" -- hier is het geen vangnet, maar
de kernstrategie zelf, expliciet zo gewenst.

Winst nemen uit de bullish-reflex: TrailingStopTracker bepaalt wanneer
de candle voorbij zijn piek is -- zelfde mechanisme als bij reguliere
directionele trades.

BELANGRIJK: dit maakt TradingOrchestrator's graduele BUY/SELL-logica
overbodig voor DIT kapitaal -- die modules blijven bestaan, maar worden
hier niet gebruikt. Zie PLAN.md.
"""

import asyncio
import json
import os
import time
import subprocess
from enum import Enum
from typing import Optional

from rss_news_client import RssNewsClient
from messari_news_client import MessariNewsClient
from llm_sentiment_engine import LlmSentimentEngine
from geckoterminal_client import GeckoTerminalClient
from binance_klines_client import BinanceKlinesClient
from safety_override import compute_fixed_combined_score, compute_combined_volatility_sigma
from flash_event_model import detect_flash_event
from gbm_range_model import apply_regime_bias, evaluate_reflex_transition_economics
from position_planner import TrailingStopTracker
from lp_manager import LpManager, LpPositionConfig, VolatilityRegime, select_optimal_volatility_regime
from hedera_rpc_client import HederaRpcClient, NetworkConfig
import telegram_notify
from config import (
    HEDERA_NETWORK, NETWORK_SETTINGS,
    resolve_testnet_addresses, resolve_mainnet_addresses,
    resolve_testnet_v2_addresses, resolve_mainnet_v2_addresses,
)


POLL_INTERVAL_SECONDS = 60

# Fractie van de beschikbare balans die het vangnet (zie _cycle()) inzet
# bij het openen van een LP-positie -- op verzoek (26 aug 2026) tijdelijk
# op 90% gezet i.p.v. 100%, zodat er bewust wat HBAR achterblijft om
# verder te kunnen testen. Zet terug naar 1.0 zodra dat niet meer nodig is.
LP_SAFETYNET_DEPLOY_FRACTION = float(os.environ.get("LP_SAFETYNET_DEPLOY_FRACTION", "0.9"))

# Absolute ondergrens (in HBAR) die ALTIJD in de wallet moet achterblijven,
# ongeacht de deploy-fractie hierboven -- op verzoek (26 aug 2026): de
# gebruiker hield historisch zelf altijd 50 HBAR achter de hand bij
# handmatig beheer. Bij een grote positie kan het percentage al genoeg
# reserve geven; bij een kleine positie is een percentage alleen niet
# genoeg (gaskosten zijn ongeveer constant in absolute termen, niet
# schalend met de positiegrootte). De daadwerkelijke reserve is het
# GROOTSTE van beide -- zelfde patroon als GAS_RESERVE_USD/
# MIN_GAS_RESERVE_HBAR elders in dit bestand.
LP_SAFETYNET_MIN_RESERVE_HBAR = float(os.environ.get("LP_SAFETYNET_MIN_RESERVE_HBAR", "50"))
SENTIMENT_REFRESH_SECONDS = 5 * 60

# Gedifferentieerde sentiment-halfwaardetijd per asset (28 aug 2026, op
# verzoek): BTC (large-cap, snelle/liquide prijsvorming) veroudert
# sneller dan HBAR (kleinere cap, tragere informatieverwerking).
# AANNAME, geen empirisch geijkte waarde -- hier instelbaar.
SENTIMENT_HALF_LIFE_HOURS_BY_ASSET = {
    "BTC": 1.5,
    "HBAR": 6.0,
}

# Volatiliteitsregime niet elke cyclus herberekenen (bedoeld voor
# uur-schaal-veranderingen, niet minuut-schaal) -- elke 4 uur is genoeg
# (26 aug 2026, aansluitend op compute_volatility_regime()'s eigen
# docstring: "periodiek (elke paar uur), niet bij elke prijs-poll").
VOLATILITY_REGIME_REFRESH_SECONDS = 4 * 60 * 60
REGIME_THRESHOLD = 0.55
# Verhoogd van 0.4 naar 0.55 (27 aug 2026), op basis van empirische
# analyse van de 6 eerdere BULLISH_REFLEX-triggers sinds 24 augustus: bij
# een drempel van 0.4 leidden slechts 2 van de 6 (33%) tot een
# betekenisvolle koersbeweging (>3%), de overige 4 (waaronder beide
# triggers van vandaag) tot vrijwel niets (0.04%-1.17%). Alleen de
# trigger met de hoogste confidence (0.55, 24 aug) leverde een sterke
# beweging op (+6.39%). Kleine steekproef (n=6), dus geen absolute
# garantie, maar sterk genoeg patroon om de drempel te verhogen.

# Gematigde-signaal-zone (28 aug 2026, op verzoek) -- introduceert een
# DERDE optie tussen "normaal LP'en" en "volledig uitstappen"
# (BULLISH_REFLEX/BEARISH_REFLEX): bij een signaal dat duidelijk richting
# heeft maar nog niet sterk genoeg is voor een volledige overstap, blijft
# de bot IN de pool, maar met een BREDERE range (via een hoger GBM-
# betrouwbaarheidsniveau) -- verdedigt tegen een grotere beweging, terwijl
# de (empirisch bevestigd, momentum-gekoppelde) hogere fee-APR nog wordt
# meegenomen. Vervangt het eerdere, binaire alles-of-niets-gedrag voor
# dit tussengebied. AANNAME, geen empirisch geijkte waarde.
MODERATE_SENTIMENT_THRESHOLD = 0.30  # boven dit niveau: bredere range i.p.v. de standaard 80%-band
MODERATE_ZONE_CONFIDENCE_LEVEL = 0.95  # verhoogd betrouwbaarheidsniveau -> bredere GBM-range


def determine_gbm_confidence_level(combined_score: float) -> float:
    """
    Geeft het te gebruiken GBM-betrouwbaarheidsniveau terug op basis van
    de signaalsterkte: standaard (0.80) bij een zwak/neutraal signaal,
    verhoogd (0.95, dus een bredere range) zodra het signaal de
    gematigde-zone-drempel overschrijdt maar nog onder REGIME_THRESHOLD
    blijft (waarboven de bot alsnog volledig uitstapt via BULLISH_REFLEX/
    BEARISH_REFLEX).
    """
    if abs(combined_score) >= MODERATE_SENTIMENT_THRESHOLD:
        return MODERATE_ZONE_CONFIDENCE_LEVEL
    return 0.80  # standaardwaarde, zelfde als compute_gbm_confidence_interval()'s default

DRY_RUN = os.environ.get("DRY_RUN", "true").lower() == "true"


class Regime(Enum):
    LP_MODE = "lp_mode"
    BULLISH_REFLEX = "bullish_reflex"
    BEARISH_REFLEX = "bearish_reflex"


class RegimeOrchestrator:
    def __init__(self, db):
        self.db = db
        self.rss_news = RssNewsClient()
        self.messari_news = MessariNewsClient()
        self.llm = LlmSentimentEngine()
        self.geckoterminal = GeckoTerminalClient()
        self.binance_klines = BinanceKlinesClient()

        self.total_capital_usdc = float(os.environ.get("REGIME_TOTAL_CAPITAL_USDC", "2000"))
        self.current_regime = Regime.LP_MODE
        self.trailing_tracker: Optional[TrailingStopTracker] = None
        # Actieve reflex-episode-id (27 aug 2026) -- None zolang we in
        # LP_MODE zitten, anders de id van de rij in reflex_episodes die
        # bij het uitstappen wordt afgesloten met de uitstapprijs.
        self._active_reflex_episode_id: Optional[int] = None
        # Voorkomt een ongecontroleerde herhaal-lus (26 aug 2026, empirisch
        # gevonden: zonder dit deed het vangnet ELKE cyclus opnieuw een
        # herbalancerings-swap zolang open_position() bleef falen, wat
        # binnen enkele cycli honderden HBAR onnodig omzette). Het vangnet
        # probeert nu MAXIMAAL EEN KEER per opstart -- bij falen is
        # handmatige controle vereist (foutmelding gaat naar Telegram),
        # geen automatische herhaling.
        self._safetynet_attempted = False
        # Dynamisch volatiliteitsregime (26 aug 2026) -- was voorheen altijd
        # de default NORMAL, nooit daadwerkelijk aan live prijsdata gekoppeld.
        self._cached_volatility_regime = VolatilityRegime.NORMAL
        self._last_volatility_refresh = 0.0

        self._cached_btc_score = 0.0
        self._cached_hbar_score = 0.0
        # Volatility_sigma-caches (28 aug 2026, voor het GBM-range-model) --
        # 0.5 als neutrale startwaarde, zelfde als de fallback bij een
        # mislukte LLM-analyse.
        self._cached_btc_volatility_sigma = 0.5
        self._cached_hbar_volatility_sigma = 0.5
        # Echte, gemeten uurvolatiliteit (28 aug 2026, voor het GBM-model) --
        # 0.006072 (0.6072%) als redelijke startwaarde, gebaseerd op de
        # eerder vandaag empirisch gemeten HBAR-uurvolatiliteit, totdat de
        # eerste verversing draait.
        self._cached_hourly_volatility = 0.006072
        self._cached_macro_regime = "sideways"

        # Flash-event-detectie en -verdediging (28 aug 2026, op verzoek) --
        # bewust LOS van het Regime-systeem (LP_MODE/BULLISH_REFLEX/
        # BEARISH_REFLEX), want dit is richtingsonafhankelijk
        # (volatiliteits-gedreven kapitaalbehoud), niet sentiment-
        # gedreven. Onthoudt de VORIGE sentiment-score per asset (om
        # d(mu)/dt te kunnen berekenen bij de volgende verversing), en
        # of de bot momenteel in "verdedigingsmodus" zit (LP-positie
        # bewust leeg, wacht tot de volatiliteit is gaan liggen).
        self._previous_btc_score = 0.0
        self._previous_hbar_score = 0.0
        self._flash_defense_until = 0.0  # 0.0 = niet actief
        self.flash_defense_duration_seconds = float(
            os.environ.get("FLASH_DEFENSE_DURATION_SECONDS", str(30 * 60))
        )
        self._last_sentiment_refresh = 0.0
        self._processed_news_ids: set = set()

        # Cooldown tegen flapping: als combined_score rond de drempel
        # schommelt, mag de bot niet elke minuut heen-en-weer schakelen
        # (elke overgang kost swap-fees/slippage). Winst-name via de
        # trailing-stop tijdens BULLISH_REFLEX is hiervan uitgezonderd --
        # dat moet altijd direct kunnen, ongeacht de cooldown.
        self.regime_cooldown_seconds = float(os.environ.get("REGIME_COOLDOWN_SECONDS", str(30 * 60)))
        self._last_transition_at = 0.0

        # Cooldown specifiek voor LP-herbalancering (28 aug 2026, op
        # verzoek) -- voorkomt onnodige gas-kosten bij een prijs die
        # precies op de rand van de range heen-en-weer beweegt. 15 minuten
        # als redelijke, instelbare standaardwaarde (korter dan de
        # regime-cooldown, want out-of-range betekent 0% fee-inkomsten
        # zolang niet herbalanceerd wordt -- te lang wachten heeft ook een
        # kostprijs).
        self.lp_rebalance_cooldown_seconds = float(
            os.environ.get("LP_REBALANCE_COOLDOWN_SECONDS", str(15 * 60))
        )
        self._last_lp_rebalance_at = 0.0

        private_key = os.environ.get("HEDERA_BOT_PRIVATE_KEY", "")
        settings = NETWORK_SETTINGS[HEDERA_NETWORK]
        network = NetworkConfig(rpc_url=settings["rpc_url"], chain_id=settings["chain_id"])
        self.rpc_client = HederaRpcClient(network, private_key) if private_key else None
        self.lp_manager: Optional[LpManager] = None
        self._usdc_decimals = 6  # default, wordt overschreven in _setup_lp_manager indien beschikbaar
        self._hbar_decimals = 8
        if self.rpc_client:
            self._setup_lp_manager()

    def _setup_lp_manager(self):
        self._usdc_decimals = 6  # veilige default, wordt hieronder overschreven
        self._hbar_decimals = 8

        try:
            if HEDERA_NETWORK == "testnet":
                base = resolve_testnet_addresses()
                v2 = resolve_testnet_v2_addresses()
            else:
                base = resolve_mainnet_addresses()
                v2 = resolve_mainnet_v2_addresses()

            self._usdc_decimals = base.usdc_decimals  # 18 op testnet-testtoken, 6 op mainnet

            whbar_addr, usdc_addr = base.whbar_token, base.usdc
            if int(whbar_addr, 16) < int(usdc_addr, 16):
                token0, token1 = whbar_addr, usdc_addr
                t0_dec, t1_dec = self._hbar_decimals, self._usdc_decimals
            else:
                token0, token1 = usdc_addr, whbar_addr
                t0_dec, t1_dec = self._usdc_decimals, self._hbar_decimals

            lp_config = LpPositionConfig(
                position_manager_address=v2.position_manager,
                token0=token0, token1=token1,
                whbar_address=whbar_addr,
                whbar_helper_address=base.whbar_helper,
                factory_address=v2.factory,
                mirror_node_url=NETWORK_SETTINGS[HEDERA_NETWORK]["mirror_node_url"],
                fee_tier=int(os.environ.get("LP_FEE_TIER", "3000")),
                token0_decimals=t0_dec, token1_decimals=t1_dec,
            )
            self.lp_manager = LpManager(self.rpc_client, lp_config)
        except ValueError as e:
            print(f"[regime] lp_manager NIET gekoppeld -- {e}")

    async def run_forever(self):
        import telegram_commands
        command_state = telegram_commands.BotCommandState()

        await self._reconcile_regime_state_on_startup()
        await self._reconcile_lp_position_on_startup()

        # Vastzittende, niet-unwrapped WHBAR opsporen en herstellen (28
        # aug 2026) -- kan ontstaan zijn door een eerdere close_position()
        # die halverwege faalde (decrease+collect gelukt, unwrap niet,
        # bv. door een RPC-storing). Draait EENMALIG bij opstarten, dus
        # ook na elke herstart.
        if self.lp_manager:
            try:
                recovered = self.lp_manager.check_and_recover_stuck_whbar()
                if recovered > 0:
                    telegram_notify.send_telegram_message(
                        f"Bij opstarten: {recovered:.4f} vastzittende, niet-"
                        f"unwrapped WHBAR gevonden en automatisch hersteld "
                        f"naar native HBAR."
                    )
            except Exception as e:
                telegram_notify.report_error(
                    "regime_loop: stuck-WHBAR-controle bij opstarten", str(e)
                )

        while True:
            try:
                await telegram_commands.check_for_commands(command_state, self)
                if command_state.paused:
                    print("[regime] Gepauzeerd via Telegram -- cyclus overgeslagen.")
                else:
                    await self._cycle()
            except Exception as e:
                import traceback
                print(f"FOUT in regime_loop: {e}")
                traceback.print_exc()
                telegram_notify.report_error("regime_loop", str(e))
            await asyncio.sleep(POLL_INTERVAL_SECONDS)

    async def _rebalance_if_out_of_range(self, current_price: float):
        """
        Checkt of de actieve LP-positie buiten zijn tick-range is gelopen
        (bv. na een prijsbeweging tijdens de bot niet actief was), en
        herbalanceert indien nodig -- met het BEWEZEN, vandaag opgebouwde
        patroon (get_live_pool_price, proportionele amount-afleiding,
        ruimere marge, gas-omzeiling, database-persistentie), niet de
        oudere, ongefixte LpManager.rebalance_if_needed() (26 aug 2026).

        Dit is een LOS probleem van de opstart-reconciliatie hierboven:
        die voorkomt duplicaten ("heb ik al iets lopen?"), dit checkt of
        wat er lopen is nog wel goed gepositioneerd is ("is het nog
        optimaal?"). Wordt zowel na de opstart-reconciliatie aangeroepen
        als elke reguliere cyclus, want de prijs kan op elk moment
        buiten de range lopen, niet alleen rond een herstart.
        """
        if not self.lp_manager or not self.lp_manager.state.is_open:
            return

        # Cooldown tegen te snel herhaald herbalanceren (28 aug 2026, op
        # verzoek: voorkomt onnodige gas-kosten als de prijs precies op de
        # rand van de range heen-en-weer beweegt) -- zelfde principe als
        # regime_cooldown_seconds, maar voor LP-herbalancering specifiek.
        seconds_since_last_lp_rebalance = time.time() - self._last_lp_rebalance_at
        if seconds_since_last_lp_rebalance < self.lp_rebalance_cooldown_seconds:
            return

        # Live, pool-eigen prijs gebruiken voor de beslissing zelf, niet
        # alleen voor de uitvoering erna -- zelfde reden als eerder vandaag:
        # GeckoTerminal kan verouderd zijn t.o.v. de daadwerkelijke on-chain
        # staat, en deze beslissing (wel/niet herbalanceren) moet daarop
        # gebaseerd zijn, niet op een mogelijk achterhaalde externe waarde.
        from lp_manager import get_live_pool_price
        try:
            live_price = get_live_pool_price(
                self.rpc_client, self.lp_manager.config.factory_address,
                self.lp_manager.config.token0, self.lp_manager.config.token1,
                self.lp_manager.config.fee_tier,
                self._hbar_decimals, self._usdc_decimals,
            )
        except Exception:
            live_price = current_price  # val terug op de meegegeven prijs als ophalen faalt

        if not self.lp_manager.is_price_out_of_range(live_price):
            return

        current_price = live_price  # de rest van deze functie gebruikt nu consistent de live prijs

        telegram_notify.send_telegram_message(
            f"LP-positie buiten range gelopen (prijs={current_price:.5f}) -- "
            f"herbalanceren..."
        )

        try:
            self.lp_manager.close_position(self.lp_manager.state.token_id)
            await self.db.clear_active_lp_position()
        except Exception as e:
            # Automatische, veilige verificatie (28 aug 2026): in plaats van
            # meteen een alarmerende "HANDMATIGE CONTROLE nodig"-melding te
            # sturen, checken we EERST on-chain of de close-transactie
            # daadwerkelijk mislukte, of dat alleen het ANTWOORD verloren
            # ging (bv. door een 502 van de RPC-relay) terwijl de
            # transactie zelf wel degelijk doorging. Empirisch aanleiding:
            # herhaalde 502's van testnet.hashio.io tijdens het sluiten
            # (28 aug 2026).
            token_id = self.lp_manager.state.token_id
            try:
                position = self.lp_manager.position_manager.functions.positions(token_id).call()
                still_open = position[5] > 0  # liquidity
            except Exception:
                still_open = None  # verificatie zelf mislukte ook

            if still_open is False:
                # De close IS gelukt -- alleen het antwoord ging verloren.
                self.lp_manager.state.is_open = False
                await self.db.clear_active_lp_position()

                # De exception kan precies bij de unwrap-stap zijn
                # opgetreden (28 aug 2026, empirisch bevestigd: dit
                # exacte scenario liet eerder 109.52 WHBAR onopgemerkt
                # vastzitten) -- meteen controleren en herstellen.
                recovered_msg = ""
                try:
                    recovered = self.lp_manager.check_and_recover_stuck_whbar()
                    if recovered > 0:
                        recovered_msg = (
                            f" Tevens {recovered:.4f} vastzittende WHBAR "
                            f"gevonden en hersteld naar native HBAR."
                        )
                except Exception:
                    pass  # niet kritiek -- de eerstvolgende opstart-check dekt dit ook af

                telegram_notify.send_telegram_message(
                    f"Herbalanceren (sluiten): transactie leek te falen ({e}), maar "
                    f"on-chain verificatie bevestigt dat positie {token_id} "
                    f"daadwerkelijk gesloten is. Kapitaal is veilig, geen "
                    f"handmatige actie nodig -- de volgende cyclus opent normaal "
                    f"een nieuwe positie.{recovered_msg}"
                )
            elif still_open is True:
                telegram_notify.report_error(
                    "regime_loop: herbalanceren (sluiten)",
                    f"{e} -- ON-CHAIN BEVESTIGD: positie {token_id} staat nog "
                    f"open (liquidity={position[5]}). Kapitaal zit nog veilig "
                    f"in de bestaande positie, geen actie ondernomen. Dit lijkt "
                    f"een tijdelijke netwerkfout -- de bot probeert het "
                    f"vanzelf opnieuw bij de volgende cyclus.",
                )
            else:
                telegram_notify.report_error(
                    "regime_loop: herbalanceren (sluiten)",
                    f"{e} -- kapitaal mogelijk nog (deels) in de oude positie, "
                    f"EN de automatische verificatie zelf mislukte ook. "
                    f"HANDMATIGE CONTROLE nodig.",
                )
            return

        hbar_balance = self._get_swappable_hbar_balance(current_price)
        usdc_balance = self._get_swappable_usdc_balance()
        if hbar_balance <= 0 or usdc_balance <= 0:
            telegram_notify.report_error(
                "regime_loop: herbalanceren (heropenen)",
                "Onvoldoende balans aan een van beide kanten na het sluiten -- "
                "positie NIET heropend, kapitaal staat los in de wallet.",
            )
            return

        from lp_manager import compute_amount1_for_amount0, compute_amount0_for_amount1, get_live_pool_price
        try:
            fresh_price = get_live_pool_price(
                self.rpc_client, self.lp_manager.config.factory_address,
                self.lp_manager.config.token0, self.lp_manager.config.token1,
                self.lp_manager.config.fee_tier,
                self._hbar_decimals, self._usdc_decimals,
            )
        except Exception:
            fresh_price = current_price

        combined_score_now = compute_fixed_combined_score(self._cached_btc_score, self._cached_hbar_score)
        combined_volatility_sigma_now = compute_combined_volatility_sigma(
            self._cached_btc_volatility_sigma, self._cached_hbar_volatility_sigma
        )
        combined_score_now = apply_regime_bias(combined_score_now, self._cached_macro_regime)
        tick_lower, tick_upper = self.lp_manager.compute_range_via_gbm(
            fresh_price, combined_score_now, combined_volatility_sigma_now,
            self._cached_hourly_volatility,
            macro_regime=self._cached_macro_regime,
            confidence_level=determine_gbm_confidence_level(combined_score_now),
        )

        # Herbalanceren voor maximale kapitaalbenutting (26 aug 2026,
        # terecht gevonden aandachtspunt) -- zonder dit zou de beperkende-
        # kant-logica hieronder gewoon de kleinste kant volledig gebruiken
        # en de rest van de andere kant ongebruikt laten liggen, ook als
        # een kleine swap vooraf een grotere, volledigere positie had
        # kunnen opleveren.
        await self._ensure_balanced_liquidity_ratio(fresh_price, tick_lower, tick_upper)
        hbar_balance = self._get_swappable_hbar_balance(fresh_price)
        usdc_balance = self._get_swappable_usdc_balance()

        hbar_raw_available = int(hbar_balance * (10 ** self._hbar_decimals))
        usdc_raw_available = int(usdc_balance * (10 ** self._usdc_decimals))
        needed_usdc_for_full_hbar = compute_amount1_for_amount0(
            hbar_raw_available, fresh_price, tick_lower, tick_upper,
            self._hbar_decimals, self._usdc_decimals,
        )
        if needed_usdc_for_full_hbar <= usdc_raw_available:
            hbar_raw, usdc_raw = hbar_raw_available, needed_usdc_for_full_hbar
        else:
            usdc_raw = usdc_raw_available
            hbar_raw = compute_amount0_for_amount1(
                usdc_raw_available, fresh_price, tick_lower, tick_upper,
                self._hbar_decimals, self._usdc_decimals,
            )

        try:
            self.lp_manager.open_position(
                hbar_raw, usdc_raw, fresh_price, slippage_tolerance=0.15,
                gas_limit_override=1_200_000,
                precomputed_tick_range=(tick_lower, tick_upper),
            )
            await self.db.save_active_lp_position(
                self.lp_manager.state.token_id,
                self.lp_manager.state.tick_lower,
                self.lp_manager.state.tick_upper,
            )
            telegram_notify.send_telegram_message(
                f"LP-positie geherbalanceerd: {hbar_raw/(10**self._hbar_decimals):.4f} HBAR "
                f"+ {usdc_raw/(10**self._usdc_decimals):.2f} SAUCE."
            )
            self._last_lp_rebalance_at = time.time()
        except Exception as e:
            telegram_notify.report_error(
                "regime_loop: herbalanceren (heropenen)",
                f"{e} -- kapitaal staat los in de wallet, HANDMATIGE CONTROLE nodig.",
            )

    async def _ensure_balanced_liquidity_ratio(self, current_price: float,
                                                  tick_lower: int, tick_upper: int,
                                                  max_hbar_to_use: Optional[float] = None) -> None:
        """
        Checkt of de huidige HBAR/SAUCE-balans al voldoende in verhouding
        is voor de gegeven tick-range, en swapt indien nodig -- in BEIDE
        richtingen (26 aug 2026, symmetrische versie: de eerdere losse
        implementaties in het vangnet/de reguliere overgangslogica
        checkten alleen "is SAUCE genoeg voor de volledige HBAR-inzet",
        nooit de omgekeerde richting "is HBAR genoeg voor de volledige
        SAUCE-inzet" -- wat kapitaal liet liggen als de wallet juist een
        overschot aan SAUCE had i.p.v. HBAR).

        max_hbar_to_use: optioneel plafond op de HBAR-kant (bv. het
        vangnet houdt bewust een reserve aan, dus mag niet de VOLLEDIGE
        wallet-balans als uitgangspunt nemen voor deze berekening).

        Wordt vanuit meerdere plekken aangeroepen (vangnet, reguliere
        LP_MODE-heropening, out-of-range-herbalancering) om deze logica
        niet driemaal apart te hoeven onderhouden.
        """
        from lp_manager import compute_amount1_for_amount0, compute_amount0_for_amount1

        hbar_balance = self._get_swappable_hbar_balance(current_price)
        if max_hbar_to_use is not None:
            hbar_balance = min(hbar_balance, max_hbar_to_use)
        usdc_balance = self._get_swappable_usdc_balance()
        hbar_raw = int(hbar_balance * (10 ** self._hbar_decimals))
        usdc_raw = int(usdc_balance * (10 ** self._usdc_decimals))

        if hbar_raw <= 0 and usdc_raw <= 0:
            return  # BEIDE kanten zijn leeg -- er valt niets te swappen

        # BUGFIX (27 aug 2026): was voorheen "or" i.p.v. "and" hierboven --
        # dat liet deze functie stilzwijgend NIETS doen zodra een van beide
        # kanten compleet op 0 stond (bv. net overgekomen vanuit
        # BULLISH_REFLEX, waar per definitie 0 SAUCE aanwezig is). Daardoor
        # bleef open_position() vervolgens EVEN vals uitgaan van een reeds
        # uitgevoerde swap, en probeerde met usdc_raw_available=0 een
        # positie te minten -- wat via de proportionele berekening ook
        # hbar_raw=0 opleverde, resulterend in de "Sent zero hbar to this
        # contract"-fout. Empirisch bevestigd (27 aug 2026, tijdens de
        # overgang bullish_reflex -> lp_mode): SAUCE-balans bleef op 0.00
        # staan, exact zoals deze bug voorspelt.

        needed_usdc_for_full_hbar = compute_amount1_for_amount0(
            hbar_raw, current_price, tick_lower, tick_upper,
            self._hbar_decimals, self._usdc_decimals,
        )

        if needed_usdc_for_full_hbar > usdc_raw:
            # SAUCE is de beperkende kant -- swap de helft van het
            # HBAR-overschot naar SAUCE.
            excess_usdc_needed = (needed_usdc_for_full_hbar - usdc_raw) / (10 ** self._usdc_decimals)
            hbar_to_swap = (excess_usdc_needed / current_price) / 2
            if hbar_to_swap > 0.01:  # ondergrens om micro-swaps met alleen gaskosten te voorkomen
                await self._run_swap_and_log("HBAR_TO_USDC", hbar_to_swap, None)
            return

        needed_hbar_for_full_usdc = compute_amount0_for_amount1(
            usdc_raw, current_price, tick_lower, tick_upper,
            self._hbar_decimals, self._usdc_decimals,
        )
        if needed_hbar_for_full_usdc > hbar_raw:
            # HBAR is de beperkende kant -- swap de helft van het
            # SAUCE-overschot naar HBAR.
            excess_hbar_needed = (needed_hbar_for_full_usdc - hbar_raw) / (10 ** self._hbar_decimals)
            usdc_to_swap = (excess_hbar_needed * current_price) / 2
            if usdc_to_swap > 1.0:  # ondergrens
                await self._run_swap_and_log("USDC_TO_HBAR", usdc_to_swap, None)
        # Anders: verhouding is al voldoende in balans, geen swap nodig.

    async def _reconcile_lp_position_on_startup(self):
        """
        Checkt bij het opstarten of er al een LP-positie open staat
        (26 aug 2026 -- lost een kritieke bug op: LpManager.state.is_open
        is puur in-memory, dus zonder dit "vergeet" de bot bij ELKE
        herstart dat er al een positie was, en opent het vangnet blind
        een NIEUWE bovenop de bestaande. Empirisch bevestigd: de
        nachtelijke herkalibratie-herstart veroorzaakte precies dit,
        resulterend in meerdere tegelijk openstaande posities).

        Herstelt de bekende positie in LpManager.state ALS die nog
        daadwerkelijk on-chain open staat (nooit blind vertrouwen op de
        database alleen, altijd on-chain verifieren).
        """
        if not self.lp_manager:
            return

        saved = await self.db.get_active_lp_position()
        if not saved:
            return

        try:
            position_data = self.lp_manager.position_manager.functions.positions(
                saved["token_id"]
            ).call()
            actual_liquidity = position_data[5]
        except Exception as e:
            telegram_notify.report_error(
                "regime_loop: opstart-reconciliatie",
                f"Kon opgeslagen positie {saved['token_id']} niet verifieren: {e} -- "
                f"HANDMATIGE CONTROLE nodig.",
            )
            return

        if actual_liquidity > 0:
            self.lp_manager.state.token_id = saved["token_id"]
            self.lp_manager.state.tick_lower = saved["tick_lower"]
            self.lp_manager.state.tick_upper = saved["tick_upper"]
            self.lp_manager.state.is_open = True
            self._safetynet_attempted = True  # er is al een positie, vangnet hoeft niet te vuren
            print(f"[regime] Bestaande LP-positie hersteld na herstart: "
                  f"token_id={saved['token_id']}, liquidity={actual_liquidity}")
        else:
            # Opgeslagen positie bleek toch gesloten (bv. handmatig, of via
            # een pad dat de database niet bijwerkte) -- opruimen.
            await self.db.clear_active_lp_position()
            print(f"[regime] Opgeslagen positie {saved['token_id']} bleek al gesloten, "
                  f"database-vermelding opgeruimd.")

    async def _reconcile_regime_state_on_startup(self):
        """
        Herstelt de laatst-bekende regimestatus (LP_MODE/BULLISH_REFLEX/
        BEARISH_REFLEX) bij het opstarten (27 aug 2026) -- lost een reeel,
        empirisch waargenomen probleem op: current_regime viel bij ELKE
        herstart terug op de default LP_MODE, ongeacht de daadwerkelijke,
        laatst-bekende status. Dit veroorzaakte een onterechte
        vangnet-poging (probeerde een LP-positie te openen terwijl de bot
        legitiem in bullish_reflex zat met kapitaal volledig in HBAR) en
        een misleidende "OVERGANG"-regel in de reflex_episodes-logging.

        In tegenstelling tot de LP-positie is er geen directe on-chain
        manier om "het regime" te verifieren (het is geen on-chain
        toestand, slechts een interne beslissing) -- we vertrouwen hier
        dus op de database. Als de wallet-samenstelling duidelijk niet bij
        de opgeslagen regime past (bv. regime=LP_MODE maar geen LP-positie
        EN geen substantieel USDC-saldo), loggen we een waarschuwing maar
        overschrijven we niets automatisch -- handmatige controle is dan
        verstandiger dan een gok.
        """
        saved = await self.db.get_regime_state()
        if not saved:
            print("[regime] Geen opgeslagen regimestatus gevonden -- start in de default LP_MODE.")
            return

        try:
            self.current_regime = Regime(saved["current_regime"])
        except ValueError:
            print(f"[regime] Onbekende opgeslagen regime-waarde "
                  f"'{saved['current_regime']}' -- blijft op de default LP_MODE.")
            return

        self._active_reflex_episode_id = saved["active_reflex_episode_id"]

        if self.current_regime == Regime.BULLISH_REFLEX and saved["trailing_entry_price"]:
            self.trailing_tracker = TrailingStopTracker(
                entry_price=saved["trailing_entry_price"], trailing_distance_pct=0.05,
                initial_stop_loss=saved["trailing_entry_price"] * 0.95,
            )

        print(f"[regime] Regimestatus hersteld na herstart: {self.current_regime.value} "
              f"(reflex-episode-id={self._active_reflex_episode_id})")

        # Telegram-melding (27 aug 2026) -- zonder dit is een herstart die
        # de status correct herstelt volledig stil, wat na een eerdere
        # foutmelding onnodig onzekerheid kan geven of alles goed is gegaan.
        if self.current_regime != Regime.LP_MODE:
            telegram_notify.send_telegram_message(
                f"Bot herstart -- regimestatus correct hersteld: "
                f"{self.current_regime.value}. Geen ongewenste actie ondernomen."
            )

    async def _refresh_volatility_regime_if_due(self):
        """
        Werkt self._cached_volatility_regime bij (26 aug 2026, herzien
        27 aug 2026) -- was voorheen altijd de default NORMAL, nooit
        daadwerkelijk aan live data gekoppeld. Draait elke paar uur, niet
        elke cyclus (zie VOLATILITY_REGIME_REFRESH_SECONDS).

        HERZIEN (27 aug 2026): gebruikt nu select_optimal_volatility_regime()
        i.p.v. compute_volatility_regime() -- die laatste keek ALLEEN naar
        marktvolatiliteit, deze houdt ook rekening met de economie
        (kapitaalgrootte vs. herbalancerings-kosten vs. verwachte
        fee-opbrengst). Empirisch bevestigd via backtest: bij klein
        kapitaal wint een bredere range, bij groter kapitaal een smallere
        -- een vaste, alleen-op-volatiliteit-gebaseerde keuze miste dit
        volledig.
        """
        if (time.time() - self._last_volatility_refresh) < VOLATILITY_REGIME_REFRESH_SECONDS:
            return

        try:
            # 1000 uur (~41,7 dagen, Binance's maximum per aanroep) i.p.v.
            # 48 uur (27 aug 2026) -- een kort venster kan toevallig 0
            # herbalanceringen op ALLE breedtes laten zien (bv. een
            # rustige periode), waardoor de economische afweging triviaal
            # altijd LOW kiest (hoogste fee-schatting, kosten overal nul)
            # ongeacht kapitaalgrootte -- empirisch waargenomen bij de
            # eerste live-poging. Een langer venster geeft een
            # statistisch betekenisvollere schatting van de daadwerkelijke
            # herbalancerings-frequentie.
            klines = self.binance_klines.get_klines("HBAR", interval="1h", limit=1000)
            closes = [k.close for k in klines]
            capital_hbar = self.rpc_client.get_hbar_balance() if self.rpc_client else 0.0
            self._cached_volatility_regime = select_optimal_volatility_regime(
                closes, float(capital_hbar)
            )

            # Echte, gemeten uurvolatiliteit cachen (28 aug 2026, voor het
            # GBM-range-model) -- zelfde berekening als compute_volatility_
            # regime() intern gebruikt, hier apart bewaard zodat we 'm
            # rechtstreeks kunnen gebruiken zonder een dubbele Binance-aanroep.
            import statistics
            hourly_returns = [
                (closes[i] - closes[i - 1]) / closes[i - 1]
                for i in range(1, len(closes)) if closes[i - 1] != 0
            ]
            if len(hourly_returns) >= 3:
                self._cached_hourly_volatility = statistics.pstdev(hourly_returns)

            # Macro-regimedetectie (28 aug 2026, op verzoek) -- hergebruikt
            # dezelfde, al-opgehaalde closes-data, geen extra Binance-
            # aanroep nodig. We hebben hier ~41,7 dagen data (Binance's
            # maximum per aanroep), dus lookback_days=30 gebruikt bijna
            # de volledige beschikbare reeks.
            from macro_regime_model import detect_macro_regime
            macro_result = detect_macro_regime(closes, lookback_days=30)
            self._cached_macro_regime = macro_result.regime.value

            print(f"[regime] Volatiliteitsregime bijgewerkt (economisch-bewust): "
                  f"{self._cached_volatility_regime.value} (kapitaal={capital_hbar:.2f} HBAR), "
                  f"gemeten uurvolatiliteit={self._cached_hourly_volatility*100:.4f}%, "
                  f"macro-regime={self._cached_macro_regime} "
                  f"(momentum={macro_result.momentum_pct*100:+.1f}% over 30 dagen)")
        except Exception as e:
            telegram_notify.report_error("regime_loop: volatiliteitsregime verversen", str(e))
            # self._cached_volatility_regime blijft op de vorige waarde staan

        self._last_volatility_refresh = time.time()

    async def _trigger_flash_defense(self, asset: str, flash_result) -> None:
        """
        Reageert op een gedetecteerde flash-event (28 aug 2026): sluit de
        LP-positie onmiddellijk (indien open) en activeert de
        verdedigingsperiode -- het doel verschuift van "fees verdienen"
        naar "kapitaalbehoud" totdat de volatiliteit is gaan liggen.

        Gebruikt hetzelfde, vandaag beproefde patroon voor het veilig
        sluiten (on-chain-verificatie na een eventuele mislukking, zie
        _rebalance_if_out_of_range() voor het origineel).
        """
        telegram_notify.send_telegram_message(
            f"FLASH-EVENT GEDETECTEERD ({asset}): sentiment-sprong "
            f"{flash_result.delta_sentiment:+.2f} binnen een verversing, "
            f"confidence={flash_result.confidence:.2f} (onder de drempel). "
            f"Verdedigingsmodus geactiveerd voor "
            f"{self.flash_defense_duration_seconds/60:.0f} minuten -- "
            f"LP-positie wordt (indien open) direct gesloten."
        )

        self._flash_defense_until = time.time() + self.flash_defense_duration_seconds

        if not self.lp_manager or not self.lp_manager.state.is_open:
            return

        token_id = self.lp_manager.state.token_id
        try:
            self.lp_manager.close_position(token_id)
            await self.db.clear_active_lp_position()
            telegram_notify.send_telegram_message(
                f"Flash-verdediging: LP-positie {token_id} succesvol gesloten."
            )
        except Exception as e:
            # Zelfde veilige verificatie-patroon als elders (28 aug 2026)
            try:
                position = self.lp_manager.position_manager.functions.positions(token_id).call()
                still_open = position[5] > 0
            except Exception:
                still_open = None

            if still_open is False:
                self.lp_manager.state.is_open = False
                await self.db.clear_active_lp_position()
                telegram_notify.send_telegram_message(
                    f"Flash-verdediging: sluiten leek te falen ({e}), maar "
                    f"on-chain verificatie bevestigt dat positie {token_id} "
                    f"daadwerkelijk gesloten is."
                )
            else:
                telegram_notify.report_error(
                    "regime_loop: flash-verdediging sluiten",
                    f"{e} -- KRITIEK: kon LP-positie {token_id} niet bevestigd "
                    f"sluiten tijdens een gedetecteerde flash-event. "
                    f"HANDMATIGE CONTROLE DRINGEND VEREIST.",
                )

    async def _refresh_sentiment_if_due(self):
        if (time.time() - self._last_sentiment_refresh) < SENTIMENT_REFRESH_SECONDS:
            return

        for asset in ("BTC", "HBAR"):
            items = self.rss_news.fetch_news(asset, max_age_hours=4.0)
            # Messari's News API uitgeschakeld (27 aug 2026) -- vereist een
            # betaald abonnement-tier dat momenteel niet actief is (401/403
            # bevestigd, geen codefout). Regel hieronder simpelweg
            # uncommenten zodra dat wel het geval is -- de client zelf is
            # al volledig af en getest tegen de echte, gedocumenteerde
            # Messari-API-structuur.
            # items += self.messari_news.fetch_news(asset, max_age_hours=4.0)
            new_items = [i for i in items if i.id not in self._processed_news_ids]
            if not new_items:
                continue

            results = [self.llm.analyze_headline(asset, i.title) for i in new_items]
            timestamps = [i.published_at for i in new_items]

            # Gedifferentieerde halfwaardetijd per asset (28 aug 2026, op
            # verzoek): BTC is een large-cap met snelle, liquide
            # prijsvorming -- nieuws wordt binnen 1-2u grotendeels
            # ingeprijsd. HBAR is een kleinere-cap met tragere
            # informatieverwerking -- nieuws blijft langer relevant.
            # AANNAME, geen empirisch geijkte waarde -- instelbaar hier.
            half_life = SENTIMENT_HALF_LIFE_HOURS_BY_ASSET.get(asset, 1.5)

            score = LlmSentimentEngine.aggregate_with_decay(results, timestamps, half_life_hours=half_life)
            volatility_sigma = LlmSentimentEngine.aggregate_volatility_with_decay(
                results, timestamps, half_life_hours=half_life
            )

            # KRITIEK: elke losse headline-score loggen naar sentiment_log --
            # zonder dit heeft recalibrate_from_live_history.py (de nachtelijke
            # zelf-herkalibratie) niets meer om uit te putten, aangezien
            # TradingOrchestrator (die dit voorheen deed) niet meer draait.
            for item, result in zip(new_items, results):
                await self.db.log_sentiment(
                    asset=asset, headline=item.title,
                    sentiment_score=result.sentiment_score,
                    confidence=result.confidence,
                    is_idiosyncratic=result.is_idiosyncratic,
                    rationale=result.rationale, source="llm",
                    volatility_sigma=result.volatility_sigma,
                )

            if asset == "BTC":
                previous_score = self._previous_btc_score
                self._previous_btc_score = score  # voor de VOLGENDE verversing
            else:
                previous_score = self._previous_hbar_score
                self._previous_hbar_score = score

            confidence_now = LlmSentimentEngine.aggregate_confidence_with_decay(results, timestamps)
            flash_result = detect_flash_event(previous_score, score, confidence_now)
            if flash_result.is_flash_event:
                await self._trigger_flash_defense(asset, flash_result)

            if asset == "BTC":
                self._cached_btc_score = score
                self._cached_btc_volatility_sigma = volatility_sigma
            else:
                self._cached_hbar_score = score
                self._cached_hbar_volatility_sigma = volatility_sigma

            for i in new_items:
                self._processed_news_ids.add(i.id)

        self._last_sentiment_refresh = time.time()

    def _determine_target_regime(self, combined_score: float) -> Regime:
        if combined_score >= REGIME_THRESHOLD:
            return Regime.BULLISH_REFLEX
        elif combined_score <= -REGIME_THRESHOLD:
            return Regime.BEARISH_REFLEX
        return Regime.LP_MODE

    async def _cycle(self):
        await self._refresh_sentiment_if_due()
        await self._refresh_volatility_regime_if_due()
        combined_score = compute_fixed_combined_score(self._cached_btc_score, self._cached_hbar_score)

        try:
            current_price = self.geckoterminal.get_pool_snapshot().price_usd
        except Exception as e:
            telegram_notify.report_error("regime_loop: prijs ophalen", str(e))
            return

        # Flash-verdedigingsperiode (28 aug 2026) -- als actief, slaat de
        # rest van deze cyclus (herbalanceren, vangnet, regime-overgangen)
        # bewust over. De positie is al gesloten door _trigger_flash_
        # defense() op het moment van detectie -- hier voorkomen we alleen
        # dat de bot tussentijds weer iets opent voordat de volatiliteit
        # is gaan liggen.
        if self._flash_defense_until > time.time():
            remaining_min = (self._flash_defense_until - time.time()) / 60
            print(f"[regime] Flash-verdedigingsmodus actief, nog {remaining_min:.1f} min.")
            return

        # Checkt of een bestaande, open positie inmiddels buiten zijn range
        # is gelopen (26 aug 2026) -- los van de vangnet-check hieronder,
        # die alleen checkt OF er iets open staat, niet OF het nog goed
        # gepositioneerd is. Draait elke cyclus, dus ook direct na een
        # herstart (nadat de opstart-reconciliatie een bestaande positie
        # heeft hersteld).
        await self._rebalance_if_out_of_range(current_price)

        # VANGNET (26 aug 2026): current_regime start standaard op LP_MODE
        # (zie __init__), maar dat betekent NIET automatisch dat er ook
        # daadwerkelijk een LP-positie open staat -- open_position() wordt
        # normaal alleen aangeroepen bij een gedetecteerde OVERGANG naar
        # LP_MODE, wat bij het opstarten nooit gebeurt (er is geen vorig
        # regime om vandaan te komen). Zonder dit vangnet blijft de bot
        # voor altijd "in lp_mode hangen zonder LP" -- kapitaal staat dan
        # nutteloos los in de wallet i.p.v. fees te verdienen.
        if (self.current_regime == Regime.LP_MODE and self.lp_manager
                and not self.lp_manager.state.is_open and not self._safetynet_attempted):
            self._safetynet_attempted = True  # ALTIJD zetten, ongeacht succes/falen -- voorkomt herhaling
            total_hbar_balance = self._get_swappable_hbar_balance(current_price)

            # Reserve = het GROOTSTE van de percentage-gebaseerde marge en de
            # absolute ondergrens (26 aug 2026, op verzoek) -- zodat er bij
            # een kleine positie altijd genoeg HBAR overblijft voor een paar
            # transacties, en bij een grote positie het percentage al genoeg
            # marge geeft zonder onnodig veel HBAR inactief te laten liggen.
            percentage_reserve = total_hbar_balance * (1 - LP_SAFETYNET_DEPLOY_FRACTION)
            reserve_hbar = max(percentage_reserve, LP_SAFETYNET_MIN_RESERVE_HBAR)
            deployable_hbar = max(0.0, total_hbar_balance - reserve_hbar)

            if deployable_hbar > 0:
                from lp_manager import compute_amount1_for_amount0, compute_amount0_for_amount1
                combined_score_now = compute_fixed_combined_score(self._cached_btc_score, self._cached_hbar_score)
                combined_volatility_sigma_now = compute_combined_volatility_sigma(
                    self._cached_btc_volatility_sigma, self._cached_hbar_volatility_sigma
                )
                combined_score_now = apply_regime_bias(combined_score_now, self._cached_macro_regime)
                tick_lower, tick_upper = self.lp_manager.compute_range_via_gbm(
                    current_price, combined_score_now, combined_volatility_sigma_now,
                    self._cached_hourly_volatility,
                    macro_regime=self._cached_macro_regime,
                    confidence_level=determine_gbm_confidence_level(combined_score_now),
                )

                # Symmetrische herbalancering (26 aug 2026, vervangt eerdere
                # eenzijdige check) -- respecteert de reserve via
                # max_hbar_to_use.
                await self._ensure_balanced_liquidity_ratio(
                    current_price, tick_lower, tick_upper, max_hbar_to_use=deployable_hbar
                )
                swap_success = True

                if swap_success:
                    hbar_balance = self._get_swappable_hbar_balance(current_price)
                    # Niet meer inzetten dan het inzetbare deel, ook al kan de
                    # totale swappable balans nu toevallig hoger zijn.
                    hbar_balance = min(hbar_balance, deployable_hbar)
                    usdc_balance = self._get_swappable_usdc_balance()

                    from lp_manager import compute_amount1_for_amount0, compute_amount0_for_amount1
                    # Prijs VERVERSEN vlak voor gebruik (26 aug 2026) -- de
                    # current_price (via GeckoTerminal) kan een eigen
                    # indexerings-vertraging hebben t.o.v. de daadwerkelijke,
                    # live pool-staat -- en de pool zelf beoordeelt onze
                    # mint()-transactie altijd tegen ZIJN EIGEN actuele
                    # prijs. Daarom hier de prijs rechtstreeks uit de pool
                    # zelf halen (26 aug 2026, na herhaalde "Price slippage
                    # check"-fouten bij grotere bedragen die niet optraden
                    # bij een kleine test eerder deze week).
                    from lp_manager import get_live_pool_price
                    try:
                        fresh_price = get_live_pool_price(
                            self.rpc_client, self.lp_manager.config.factory_address,
                            self.lp_manager.config.token0, self.lp_manager.config.token1,
                            self.lp_manager.config.fee_tier,
                            self._hbar_decimals, self._usdc_decimals,
                        )
                    except Exception:
                        fresh_price = current_price  # val terug op de oude prijs als ophalen faalt
                    combined_score_now = compute_fixed_combined_score(self._cached_btc_score, self._cached_hbar_score)
                    combined_volatility_sigma_now = compute_combined_volatility_sigma(
                        self._cached_btc_volatility_sigma, self._cached_hbar_volatility_sigma
                    )
                    combined_score_now = apply_regime_bias(combined_score_now, self._cached_macro_regime)
                    tick_lower, tick_upper = self.lp_manager.compute_range_via_gbm(
                        fresh_price, combined_score_now, combined_volatility_sigma_now,
                        self._cached_hourly_volatility,
                        macro_regime=self._cached_macro_regime,
                        confidence_level=determine_gbm_confidence_level(combined_score_now),
                    )

                    hbar_raw_available = int(hbar_balance * (10 ** self._hbar_decimals))
                    usdc_raw_available = int(usdc_balance * (10 ** self._usdc_decimals))

                    # Zelfde beperkende-kant-logica als voorheen -- na de
                    # herbalancering zou dit meestal HBAR moeten zijn, maar
                    # niet gegarandeerd (bv. bij prijsbeweging tijdens de
                    # swap), dus blijft dit defensief gecheckt.
                    needed_usdc_for_full_hbar = compute_amount1_for_amount0(
                        hbar_raw_available, fresh_price, tick_lower, tick_upper,
                        self._hbar_decimals, self._usdc_decimals,
                    )
                    if needed_usdc_for_full_hbar <= usdc_raw_available:
                        hbar_raw = hbar_raw_available
                        usdc_raw = needed_usdc_for_full_hbar
                    else:
                        usdc_raw = usdc_raw_available
                        hbar_raw = compute_amount0_for_amount1(
                            usdc_raw_available, fresh_price, tick_lower, tick_upper,
                            self._hbar_decimals, self._usdc_decimals,
                        )

                    hbar_to_deploy = hbar_raw / (10 ** self._hbar_decimals)
                    usdc_to_deploy = usdc_raw / (10 ** self._usdc_decimals)
                    try:
                        self.lp_manager.open_position(
                            hbar_raw, usdc_raw, fresh_price, slippage_tolerance=0.15,
                            gas_limit_override=1_200_000,
                            precomputed_tick_range=(tick_lower, tick_upper),
                        )
                        await self.db.save_active_lp_position(
                            self.lp_manager.state.token_id,
                            self.lp_manager.state.tick_lower,
                            self.lp_manager.state.tick_upper,
                        )
                        telegram_notify.send_telegram_message(
                            f"LP-positie geopend (vangnet, na herbalancering, "
                            f"reserve={reserve_hbar:.2f} HBAR achtergehouden): "
                            f"{hbar_to_deploy:.4f} HBAR + {usdc_to_deploy:.2f} SAUCE."
                        )
                    except Exception as e:
                        telegram_notify.report_error(
                            "regime_loop: LP-positie openen (vangnet)",
                            f"{e} -- kapitaal staat los in de wallet. Vangnet probeert NIET automatisch opnieuw (voorkomt herhaal-lus) -- herstart de bot handmatig na controle.",
                        )
                else:
                    telegram_notify.report_error(
                        "regime_loop: LP-positie openen (vangnet)",
                        "Herbalancerings-swap mislukt -- LP-positie niet geopend, "
                        "kapitaal staat los in de wallet. Vangnet probeert NIET automatisch opnieuw -- herstart de bot handmatig na controle.",
                    )

        target_regime = self._determine_target_regime(combined_score)
        is_profit_take = False

        # Economische poort (28 aug 2026, op verzoek): alleen toegepast bij
        # een NIEUWE overstap VANUIT LP_MODE naar een reflex-regime (niet
        # bij het weer VERLATEN van een reflex-regime, en niet bij
        # winst-name via de trailing-stop hieronder, die altijd moet
        # kunnen doorgaan) -- weegt af of de volledige heen-en-terug-
        # cyclus (sluiten+swappen, later weer openen+swappen)
        # daadwerkelijk meerwaarde heeft t.o.v. gewoon in de pool blijven.
        if (self.current_regime == Regime.LP_MODE
                and target_regime in (Regime.BULLISH_REFLEX, Regime.BEARISH_REFLEX)):
            capital_hbar = float(self.rpc_client.get_hbar_balance()) if self.rpc_client else 0.0
            economics = evaluate_reflex_transition_economics(
                current_price=current_price,
                sentiment_mu=combined_score,
                volatility_sigma=compute_combined_volatility_sigma(
                    self._cached_btc_volatility_sigma, self._cached_hbar_volatility_sigma
                ),
                historical_hourly_volatility=self._cached_hourly_volatility,
                horizon_hours=24.0,  # aanname: verwachte duur in reflex-modus
                capital_hbar=capital_hbar,
            )
            if not economics.should_proceed:
                print(f"[regime] Overstap naar {target_regime.value} geweigerd -- economische "
                      f"poort: netto {economics.net_benefit_hbar:.2f} HBAR (vermeden IL "
                      f"{economics.expected_il_avoided_hbar:.2f} H min misgelopen fees "
                      f"{economics.expected_fee_income_foregone_hbar:.2f} H weegt niet op tegen "
                      f"de geschatte heen-en-terug-kosten van {economics.round_trip_cost_hbar:.2f} H). "
                      f"Blijft in lp_mode.")
                return

        if self.current_regime == Regime.BULLISH_REFLEX and self.trailing_tracker:
            stop_price = self.trailing_tracker.update(current_price)
            if current_price <= stop_price:
                print(f"[regime] Trailing-stop getriggerd tijdens BULLISH_REFLEX "
                      f"(prijs={current_price:.5f} <= stop={stop_price:.5f}) -- winst nemen.")
                target_regime = Regime.LP_MODE
                is_profit_take = True

        if target_regime == self.current_regime:
            print(f"[regime] Blijft in {self.current_regime.value} "
                  f"(combined_score={combined_score:+.2f}, prijs={current_price:.5f})")
            return

        # Cooldown tegen flapping -- winst-name via de trailing-stop is
        # hiervan uitgezonderd, die moet altijd direct kunnen.
        seconds_since_last = time.time() - self._last_transition_at
        if not is_profit_take and seconds_since_last < self.regime_cooldown_seconds:
            remaining_min = (self.regime_cooldown_seconds - seconds_since_last) / 60
            print(f"[regime] Overgang naar {target_regime.value} uitgesteld -- "
                  f"cooldown actief, nog {remaining_min:.1f} min.")
            return

        print(f"[regime] OVERGANG: {self.current_regime.value} -> {target_regime.value} "
              f"(combined_score={combined_score:+.2f})")

        signal_id = await self.db.log_strategy_signal(
            direction=target_regime.value, confidence=abs(combined_score),
            position_fraction=1.0, btc_score=self._cached_btc_score,
            hbar_score=self._cached_hbar_score,
            panic_override_triggered=(target_regime == Regime.BEARISH_REFLEX),
            reasoning=f"Regime-overgang {self.current_regime.value} -> {target_regime.value}"
                      f"{' (winst-name)' if is_profit_take else ''}",
        )

        if DRY_RUN:
            print(f"[DRY RUN] Zou overgaan van {self.current_regime.value} naar {target_regime.value}")
            if target_regime == Regime.BULLISH_REFLEX:
                self.trailing_tracker = TrailingStopTracker(
                    entry_price=current_price, trailing_distance_pct=0.05,
                    initial_stop_loss=current_price * 0.95,
                )
            self.current_regime = target_regime
            self._last_transition_at = time.time()
            return

        previous_regime = self.current_regime  # nodig om exit correct te loggen, voor overschrijven
        transition_succeeded = await self._execute_transition(target_regime, current_price, signal_id)
        self._last_transition_at = time.time()

        if transition_succeeded:
            # Reflex-episode-logging (27 aug 2026): exit loggen als we een
            # reflex-regime VERLATEN, entry loggen als we er een INSTAPPEN.
            # Beide kunnen in dezelfde overgang gebeuren (bv. bearish_reflex
            # -> bullish_reflex, zonder tussenstop in LP_MODE).
            if previous_regime in (Regime.BULLISH_REFLEX, Regime.BEARISH_REFLEX) \
                    and self._active_reflex_episode_id is not None:
                exit_reason = "trailing_stop" if is_profit_take else "sentiment_reverted"
                await self.db.log_reflex_exit(
                    self._active_reflex_episode_id, current_price, exit_reason
                )
                self._active_reflex_episode_id = None

            if target_regime in (Regime.BULLISH_REFLEX, Regime.BEARISH_REFLEX):
                self._active_reflex_episode_id = await self.db.log_reflex_entry(
                    target_regime.value, current_price, combined_score
                )

            self.current_regime = target_regime

            # Regimestatus persisteren (27 aug 2026) -- zodat een herstart
            # niet langer altijd terugvalt op de default LP_MODE.
            trailing_entry_price = self.trailing_tracker.entry_price if self.trailing_tracker else None
            await self.db.save_regime_state(
                self.current_regime.value, trailing_entry_price, self._active_reflex_episode_id
            )
        # Bij falen: current_regime blijft bewust ongewijzigd (de vorige,
        # bekende staat) -- de foutmelding is al verstuurd in
        # _execute_transition. Handmatige controle is dan nodig voordat
        # de bot hier weer op vertrouwt.

    # Hedera's transactiekosten zijn vastgesteld in USD-termen (fee-schedule),
    # maar worden betaald in HBAR -- een vaste HBAR-reserve zou dus fout zijn
    # in twee richtingen als de HBAR-prijs beweegt: te veel kapitaal
    # inactief bij een hoge prijs, te weinig dekking bij een lage prijs.
    # $2 dekt ruimschoots meerdere toekomstige transacties, gezien Hedera's
    # kosten doorgaans een fractie van een cent tot een paar cent per tx zijn.
    GAS_RESERVE_USD = 2.0
    # Ondergrens (op verzoek, 23 aug 2026): ongeacht de prijs nooit minder
    # dan 10 HBAR reserveren -- bij een hoge HBAR-prijs zou de USD-som
    # anders een te kleine reserve opleveren.
    MIN_GAS_RESERVE_HBAR = 10.0

    def _get_swappable_hbar_balance(self, current_price: float) -> float:
        """
        Vraagt de WERKELIJKE on-chain HBAR-balans op i.p.v. te herberekenen
        vanuit total_capital_usdc/current_price -- dat laatste zou bij een
        koersstijging tijdens BULLISH_REFLEX stelselmatig te weinig HBAR
        teruggeven (de koerswinst wordt dan nooit verzilverd), en na het
        sluiten van een LP-positie klopt de aanname van "100% in één token"
        sowieso niet meer (er komt een mix van HBAR+USDC terug).

        De gas-reserve is het GROOTSTE van (a) de USD-gebaseerde berekening
        (schaalt correct mee met de prijs) en (b) een vaste ondergrens van
        MIN_GAS_RESERVE_HBAR, zodat de reserve bij een hoge HBAR-prijs nooit
        te klein wordt.
        """
        if not self.rpc_client:
            return 0.0
        try:
            balance = self.rpc_client.get_hbar_balance()
            usd_based_reserve = self.GAS_RESERVE_USD / current_price if current_price > 0 else 0.0
            gas_reserve_hbar = max(usd_based_reserve, self.MIN_GAS_RESERVE_HBAR)
            return max(0.0, float(balance) - gas_reserve_hbar)
        except Exception as e:
            telegram_notify.report_error("regime_loop: HBAR-balans opvragen", str(e))
            return 0.0

    def _get_swappable_usdc_balance(self) -> float:
        """Zelfde principe als hierboven, voor USDC."""
        if not self.rpc_client:
            return 0.0
        try:
            if HEDERA_NETWORK == "testnet":
                base = resolve_testnet_addresses()
            else:
                base = resolve_mainnet_addresses()
            from swap_executor import ERC20_ABI
            balance = self.rpc_client.get_token_balance(
                base.usdc, ERC20_ABI, decimals=base.usdc_decimals
            )
            return max(0.0, float(balance))
        except Exception as e:
            telegram_notify.report_error("regime_loop: USDC-balans opvragen", str(e))
            return 0.0

    async def _run_swap_and_log(self, direction: str, amount: float,
                                  signal_id: Optional[int] = None) -> bool:
        """Voert een swap uit en logt het resultaat naar Postgres. Geeft True terug bij succes."""
        result = subprocess.run(
            ["python3", "execute_hbar_swap_standalone.py",
             "--direction", direction, "--amount", str(amount),
             "--network", HEDERA_NETWORK, "--engine", "v2"],
            capture_output=True, text=True,
        )
        status = "success" if result.returncode == 0 else "failed"

        # Gestructureerde output parsen (23 aug 2026 toegevoegd aan
        # execute_hbar_swap_standalone.py) -- zonder dit werden tx_hash en
        # estimated_amount_out altijd als None gelogd, wat elke vorm van
        # winst/verlies-analyse achteraf onmogelijk maakte.
        tx_hash, estimated_amount_out = None, None
        try:
            last_line = result.stdout.strip().splitlines()[-1]
            parsed = json.loads(last_line)
            tx_hash = parsed.get("tx_hash")
            estimated_amount_out = parsed.get("estimated_amount_out")
        except (IndexError, json.JSONDecodeError):
            pass  # subprocess gaf geen geldige JSON terug -- blijft None, geen crash

        await self.db.log_trade(
            direction=direction, engine="v2", network=HEDERA_NETWORK,
            amount_in=amount, estimated_amount_out=estimated_amount_out,
            actual_amount_out=None,  # SaucerSwap's exactInputSingle-return-waarde
                                       # wordt nog niet teruggegeven door de subprocess-
                                       # aanroep -- estimated_amount_out is het beste
                                       # wat we nu hebben, nog geen exacte uitkomst.
            tx_hash=tx_hash, status=status,
            strategy_signal_id=signal_id,
        )

        if status == "failed":
            telegram_notify.report_error(
                "regime_loop: swap", f"Swap {direction} ({amount:.4f}) mislukt: {result.stderr[:200]}"
            )
        else:
            # Pauze na een succesvolle swap (26 aug 2026) -- deze swap
            # liep via een APART subprocess, met zijn EIGEN RPC-client-
            # instantie. De centrale nonce-timing-fix in
            # hedera_rpc_client.wait_for_receipt() (time.sleep(2) na elke
            # bevestigde tx) geldt alleen BINNEN diezelfde procesinstantie
            # -- als DIT (aanroepende) proces meteen daarna ZELF een
            # transactie stuurt (bv. open_position() in de
            # herbalancerings-flow), kan de RPC-relay zijn nonce-teller
            # nog niet bijgewerkt hebben, wat een "Nonce too low"-fout
            # geeft (empirisch bevestigd bij een handmatige test).
            await asyncio.sleep(4)

        return status == "success"

    async def _execute_transition(self, target_regime: Regime, current_price: float,
                                    signal_id: Optional[int] = None) -> bool:
        """
        Geeft True terug als de overgang volledig is gelukt, False als er
        ergens een swap is mislukt. De aanroeper mag self.current_regime
        ALLEEN bijwerken bij True -- anders raakt de interne staat
        losgezongen van de werkelijke, on-chain positie.
        """
        # Expliciete guard: zonder rpc_client geven de balans-functies 0.0
        # terug, wat de amount>0-checks verderop stil zou laten slagen
        # (geen swap nodig bij bedrag 0) -- zonder deze check zou de bot
        # zichzelf dan valselijk als "overgang geslaagd" registreren,
        # inclusief een misleidende Telegram-bevestiging, terwijl er
        # helemaal geen wallet is aangesloten en er dus niets is gebeurd.
        if not self.rpc_client:
            telegram_notify.report_error(
                "regime_loop",
                f"Overgang naar {target_regime.value} geweigerd -- geen rpc_client "
                f"(HEDERA_BOT_PRIVATE_KEY ontbreekt?) terwijl DRY_RUN=false staat. "
                f"HANDMATIGE CONTROLE VEREIST: de bot kan geen transacties uitvoeren.",
            )
            return False

        all_succeeded = True

        if self.current_regime == Regime.LP_MODE and self.lp_manager and self.lp_manager.state.is_open:
            try:
                self.lp_manager.close_position(self.lp_manager.state.token_id)
                await self.db.clear_active_lp_position()
                telegram_notify.send_telegram_message("Regime-schakelaar: LP-positie volledig geleegd.")
            except Exception as e:
                # Zelfde automatische, veilige on-chain-verificatie als
                # elders (28 aug 2026) -- voorkomt onnodige "HANDMATIGE
                # CONTROLE"-paniek bij een transiente RPC-fout terwijl de
                # close-transactie zelf wel degelijk doorging.
                token_id = self.lp_manager.state.token_id
                try:
                    position = self.lp_manager.position_manager.functions.positions(token_id).call()
                    still_open = position[5] > 0
                except Exception:
                    still_open = None

                if still_open is False:
                    self.lp_manager.state.is_open = False
                    await self.db.clear_active_lp_position()

                    recovered_msg = ""
                    try:
                        recovered = self.lp_manager.check_and_recover_stuck_whbar()
                        if recovered > 0:
                            recovered_msg = (
                                f" Tevens {recovered:.4f} vastzittende WHBAR "
                                f"gevonden en hersteld naar native HBAR."
                            )
                    except Exception:
                        pass

                    telegram_notify.send_telegram_message(
                        f"Regime-schakelaar: sluiten leek te falen ({e}), maar "
                        f"on-chain verificatie bevestigt dat positie {token_id} "
                        f"daadwerkelijk gesloten is. Kapitaal is veilig.{recovered_msg}"
                    )
                elif still_open is True:
                    all_succeeded = False
                    telegram_notify.report_error(
                        "regime_loop: LP-positie sluiten",
                        f"{e} -- ON-CHAIN BEVESTIGD: positie {token_id} staat nog "
                        f"open (liquidity={position[5]}). Kapitaal zit nog veilig "
                        f"in de bestaande positie, geen actie ondernomen.",
                    )
                else:
                    all_succeeded = False
                    telegram_notify.report_error(
                        "regime_loop: LP-positie sluiten",
                        f"{e} -- HANDMATIGE CONTROLE VEREIST, LP-positie mogelijk "
                        f"nog (deels) open, EN de automatische verificatie zelf "
                        f"mislukte ook.",
                    )

        if target_regime == Regime.BULLISH_REFLEX:
            usdc_to_swap = self._get_swappable_usdc_balance()
            success = True
            if usdc_to_swap > 0:
                success = await self._run_swap_and_log("USDC_TO_HBAR", usdc_to_swap, signal_id)
            all_succeeded = all_succeeded and success
            if success:
                self.trailing_tracker = TrailingStopTracker(
                    entry_price=current_price, trailing_distance_pct=0.05,
                    initial_stop_loss=current_price * 0.95,
                )
                telegram_notify.send_telegram_message(
                    f"Regime-schakelaar: BULLISH_REFLEX -- {usdc_to_swap:.2f} USDC naar HBAR "
                    f"bij {current_price:.5f}."
                )

        elif target_regime == Regime.BEARISH_REFLEX:
            hbar_to_swap = self._get_swappable_hbar_balance(current_price)
            success = True
            if hbar_to_swap > 0:
                success = await self._run_swap_and_log("HBAR_TO_USDC", hbar_to_swap, signal_id)
            all_succeeded = all_succeeded and success
            if success:
                self.trailing_tracker = None
                telegram_notify.send_telegram_message(
                    f"Regime-schakelaar: BEARISH_REFLEX -- {hbar_to_swap:.4f} HBAR naar USDC "
                    f"bij {current_price:.5f}."
                )

        elif target_regime == Regime.LP_MODE:
            # Tick-range vooraf berekenen, nodig om de gedeelde
            # herbalancerings-functie hieronder de JUISTE verhouding te
            # laten aanhouden (26 aug 2026) i.p.v. altijd blind 50/50.
            combined_score_now = compute_fixed_combined_score(self._cached_btc_score, self._cached_hbar_score)
            combined_volatility_sigma_now = compute_combined_volatility_sigma(
                self._cached_btc_volatility_sigma, self._cached_hbar_volatility_sigma
            )
            combined_score_now = apply_regime_bias(combined_score_now, self._cached_macro_regime)
            tick_lower, tick_upper = self.lp_manager.compute_range_via_gbm(
                current_price, combined_score_now, combined_volatility_sigma_now,
                self._cached_hourly_volatility,
                macro_regime=self._cached_macro_regime,
                confidence_level=determine_gbm_confidence_level(combined_score_now),
            ) if self.lp_manager else (0, 0)

            if self.lp_manager:
                await self._ensure_balanced_liquidity_ratio(current_price, tick_lower, tick_upper)
            all_succeeded = True

            if all_succeeded and self.lp_manager:
                # Balans NA de herbalancerings-swap opvragen, niet vooraf
                # geschat -- dat is de daadwerkelijke inzet voor de LP-positie.
                final_hbar_balance = self._get_swappable_hbar_balance(current_price)
                final_usdc_balance = self._get_swappable_usdc_balance()

                # Zelfde robuustheids-fixes als het vangnet in _cycle()
                # (26 aug 2026): proportionele amount-afleiding + ruimere
                # marge + expliciete gas-limiet + prijs RECHTSTREEKS uit de
                # pool zelf (i.p.v. GeckoTerminal, die een eigen
                # indexerings-vertraging kan hebben t.o.v. de daadwerkelijke
                # live pool-staat -- de pool beoordeelt onze transactie
                # altijd tegen zijn EIGEN actuele prijs).
                from lp_manager import compute_amount1_for_amount0, compute_amount0_for_amount1, get_live_pool_price
                try:
                    current_price = get_live_pool_price(
                        self.rpc_client, self.lp_manager.config.factory_address,
                        self.lp_manager.config.token0, self.lp_manager.config.token1,
                        self.lp_manager.config.fee_tier,
                        self._hbar_decimals, self._usdc_decimals,
                    )
                except Exception:
                    pass  # val terug op de bestaande current_price als ophalen faalt
                combined_score_now = compute_fixed_combined_score(self._cached_btc_score, self._cached_hbar_score)
                combined_volatility_sigma_now = compute_combined_volatility_sigma(
                    self._cached_btc_volatility_sigma, self._cached_hbar_volatility_sigma
                )
                combined_score_now = apply_regime_bias(combined_score_now, self._cached_macro_regime)
                tick_lower, tick_upper = self.lp_manager.compute_range_via_gbm(
                    current_price, combined_score_now, combined_volatility_sigma_now,
                    self._cached_hourly_volatility,
                    macro_regime=self._cached_macro_regime,
                    confidence_level=determine_gbm_confidence_level(combined_score_now),
                )
                hbar_raw_available = int(final_hbar_balance * (10 ** self._hbar_decimals))
                usdc_raw_available = int(final_usdc_balance * (10 ** self._usdc_decimals))
                needed_usdc_for_full_hbar = compute_amount1_for_amount0(
                    hbar_raw_available, current_price, tick_lower, tick_upper,
                    self._hbar_decimals, self._usdc_decimals,
                )
                if needed_usdc_for_full_hbar <= usdc_raw_available:
                    hbar_raw, usdc_raw = hbar_raw_available, needed_usdc_for_full_hbar
                else:
                    usdc_raw = usdc_raw_available
                    hbar_raw = compute_amount0_for_amount1(
                        usdc_raw_available, current_price, tick_lower, tick_upper,
                        self._hbar_decimals, self._usdc_decimals,
                    )

                try:
                    self.lp_manager.open_position(
                        hbar_raw, usdc_raw, current_price,
                        slippage_tolerance=0.15,
                        gas_limit_override=1_200_000,
                        precomputed_tick_range=(tick_lower, tick_upper),
                    )
                    await self.db.save_active_lp_position(
                        self.lp_manager.state.token_id,
                        self.lp_manager.state.tick_lower,
                        self.lp_manager.state.tick_upper,
                    )
                    self.trailing_tracker = None
                    telegram_notify.send_telegram_message(
                        f"Regime-schakelaar: terug naar LP_MODE -- {hbar_raw/(10**self._hbar_decimals):.4f} HBAR "
                        f"+ {usdc_raw/(10**self._usdc_decimals):.2f} USDC in de pool."
                    )
                except Exception as e:
                    all_succeeded = False
                    telegram_notify.report_error(
                        "regime_loop: LP-positie openen",
                        f"{e} -- herbalancerings-swap is al gebeurd, maar de LP-positie zelf niet "
                        f"geopend. Kapitaal staat nu los in HBAR/USDC. HANDMATIGE CONTROLE VEREIST.",
                    )

        if not all_succeeded:
            telegram_notify.report_error(
                "regime_loop",
                f"Overgang naar {target_regime.value} DEELS OF VOLLEDIG MISLUKT -- "
                f"regime blijft geregistreerd als {self.current_regime.value}, maar de "
                f"werkelijke on-chain positie is mogelijk inconsistent. HANDMATIGE "
                f"CONTROLE VEREIST voordat de bot hier verder op vertrouwt.",
            )

        return all_succeeded
