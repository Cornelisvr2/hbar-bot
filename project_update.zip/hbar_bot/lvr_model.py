"""
lvr_model.py

Loss Versus Rebalancing (LVR) -- kwantificeert specifiek de winst die
arbitrageurs uit de pool halen wanneer zij de poolprijs in lijn brengen
met een externe, gecentraliseerde referentieprijs (28 aug 2026).

ANDERS dan impermanent loss (die je LP-positie vergelijkt met simpelweg
vasthouden): LVR meet de directe arbitrage-winst zelf, een preciezere
maatstaf voor "hoeveel kost toxic flow me precies".

BELANGRIJKE CORRECTIE (28 aug 2026): de oorspronkelijk aangeleverde
discrete formule (L*(P0-P1)^2) bleek dimensioneel onjuist en week
enorm af van de daadwerkelijke waarde (~3.590x verschil in een
testgeval). Zelf afgeleid en geverifieerd via sympy tegen de
standaard Uniswap-V3-liquiditeitswiskunde (x=L/sqrt(P), y=L*sqrt(P)):

    LVR_discreet = L * (sqrt(P0) - sqrt(P1))^2 / sqrt(P0)

Dit is de daadwerkelijke arbitrage-winst (in token Y) als de prijs
abrupt van P0 naar P1 beweegt, ZOLANG P1 binnen de actieve
liquiditeitsrange [Pa, Pb] valt.
"""

import math
from dataclasses import dataclass


@dataclass
class LvrResult:
    lvr_amount: float  # in token Y (bv. SAUCE/USDC)
    price_ratio: float  # P1/P0, ter info


def compute_discrete_lvr(liquidity: float, price_before: float, price_after: float) -> LvrResult:
    """
    Discrete LVR voor een abrupte prijsbeweging (bv. een flash crash),
    geverifieerd via sympy tegen de standaard Uniswap-V3-wiskunde (28 aug
    2026). Geeft de arbitrage-winst in token Y terug.

    LET OP: geldig zolang price_after nog binnen de actieve
    liquiditeitsrange valt -- buiten de range is de positie al volledig
    in een van beide tokens, en verandert de dynamiek.
    """
    if liquidity <= 0 or price_before <= 0 or price_after <= 0:
        return LvrResult(lvr_amount=0.0, price_ratio=1.0)

    lvr_amount = liquidity * (math.sqrt(price_before) - math.sqrt(price_after)) ** 2 / math.sqrt(price_before)
    return LvrResult(lvr_amount=lvr_amount, price_ratio=price_after / price_before)


def compute_continuous_lvr_rate(liquidity: float, current_price: float, sigma: float) -> float:
    """
    LET OP (28 aug 2026): in tegenstelling tot compute_discrete_lvr()
    hierboven, is DEZE formule NIET volledig, onafhankelijk geverifieerd
    -- bij het narekenen bleek de aangenomen Gamma-formule (L/(2*P^1.5))
    niet overeen te komen met een zelf-afgeleide tweede-afgeleide-
    benadering (die 3L/(4*P^2.5) gaf, een andere macht van P). Dit kan
    wijzen op een verschil in conventie/definitie van Gamma in de
    LVR-literatuur t.o.v. een naieve tweede-afgeleide-aanpak, of op een
    fout ergens in de afleiding -- dat is niet met zekerheid vastgesteld.

    Gebruik deze functie voorlopig UITSLUITEND als indicatieve schatting,
    NIET als basis voor automatische handelsbeslissingen, totdat dit
    grondiger geverifieerd is (bv. tegen een gezaghebbende bron of
    gepubliceerde referentiewaarden).

    Continue LVR-'bleed'-snelheid (per tijdseenheid, zelfde eenheid als
    sigma), voor reguliere (niet-flash-crash) volatiliteit.
    """
    if liquidity <= 0 or current_price <= 0 or sigma < 0:
        return 0.0

    gamma = liquidity / (2 * current_price ** 1.5)
    lvr_rate = 0.5 * (sigma ** 2) * (current_price ** 2) * gamma
    return lvr_rate
