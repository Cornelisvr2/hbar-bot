"""
postgres_client.py

Schrijft naar de tabellen uit db_schema.sql: sentiment_log,
strategy_signals, trades, open_positions. Asyncpg-gebaseerd, voor
gebruik in de asyncio-event-loop van main_orchestrator.py.
"""

import os
from datetime import datetime
from dataclasses import dataclass
from typing import Optional, List

import asyncpg


@dataclass
class DailyStats:
    total_trades: int
    successful_trades: int
    failed_trades: int
    avg_btc_sentiment: float
    avg_hbar_sentiment: float
    panic_overrides_triggered: int
    net_hbar_change: float
    net_usdc_change: float


class PostgresClient:
    def __init__(self, dsn: Optional[str] = None):
        self.dsn = dsn or os.environ.get("DATABASE_URL")
        self._pool: Optional[asyncpg.Pool] = None

    async def connect(self):
        if not self.dsn:
            raise EnvironmentError("DATABASE_URL niet gezet.")
        self._pool = await asyncpg.create_pool(self.dsn, min_size=1, max_size=5)

    async def close(self):
        if self._pool:
            await self._pool.close()

    async def log_sentiment(self, asset: str, headline: str, sentiment_score: float,
                              confidence: float, is_idiosyncratic: bool,
                              rationale: str = "", source: str = "llm",
                              volatility_sigma: float = 0.5) -> int:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO sentiment_log
                    (asset, headline, sentiment_score, confidence, is_idiosyncratic, rationale, source, volatility_sigma)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                RETURNING id
                """,
                asset, headline, sentiment_score, confidence, is_idiosyncratic, rationale, source, volatility_sigma,
            )
            return row["id"]

    async def log_strategy_signal(self, direction: str, confidence: float, position_fraction: float,
                                    btc_score: float, hbar_score: float,
                                    panic_override_triggered: bool = False, reasoning: str = "") -> int:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO strategy_signals
                    (direction, confidence, position_fraction, btc_score, hbar_score,
                     panic_override_triggered, reasoning)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id
                """,
                direction, confidence, position_fraction, btc_score, hbar_score,
                panic_override_triggered, reasoning,
            )
            return row["id"]

    async def log_trade(self, direction: str, engine: str, network: str, amount_in: float,
                          estimated_amount_out: Optional[float], actual_amount_out: Optional[float],
                          tx_hash: Optional[str], status: str,
                          strategy_signal_id: Optional[int] = None) -> int:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO trades
                    (direction, engine, network, amount_in, estimated_amount_out,
                     actual_amount_out, tx_hash, status, strategy_signal_id)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                RETURNING id
                """,
                direction, engine, network, amount_in, estimated_amount_out,
                actual_amount_out, tx_hash, status, strategy_signal_id,
            )
            return row["id"]

    async def open_position(self, entry_price: float, initial_stop_loss: Optional[float],
                              trailing_distance_pct: Optional[float], quantity_hbar: float,
                              trade_id: Optional[int] = None) -> int:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO open_positions
                    (entry_price, initial_stop_loss, trailing_distance_pct,
                     highest_price_seen, quantity_hbar, trade_id, is_open)
                VALUES ($1, $2, $3, $1, $4, $5, TRUE)
                RETURNING id
                """,
                entry_price, initial_stop_loss, trailing_distance_pct, quantity_hbar, trade_id,
            )
            return row["id"]

    async def update_highest_price(self, position_id: int, highest_price: float):
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE open_positions SET highest_price_seen = $1 WHERE id = $2",
                highest_price, position_id,
            )

    async def close_position(self, position_id: int):
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE open_positions SET is_open = FALSE, closed_at = now() WHERE id = $1",
                position_id,
            )

    async def get_open_positions(self) -> List[dict]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM open_positions WHERE is_open = TRUE")
            return [dict(r) for r in rows]

    async def save_active_lp_position(self, token_id: int, tick_lower: int, tick_upper: int):
        """
        Slaat de actieve LP-positie op, zodat de bot dit na een herstart
        kan herstellen (26 aug 2026 -- lost het "vergeet open positie na
        herstart"-probleem op). Verwijdert eerst elke bestaande rij --
        er hoort er maximaal een te zijn.
        """
        async with self._pool.acquire() as conn:
            await conn.execute("DELETE FROM active_lp_position")
            await conn.execute(
                "INSERT INTO active_lp_position (token_id, tick_lower, tick_upper) "
                "VALUES ($1, $2, $3)",
                token_id, tick_lower, tick_upper,
            )

    async def get_active_lp_position(self) -> Optional[dict]:
        """Geeft de opgeslagen actieve LP-positie terug, of None als er geen is."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT token_id, tick_lower, tick_upper FROM active_lp_position "
                "ORDER BY id DESC LIMIT 1"
            )
            return dict(row) if row else None

    async def clear_active_lp_position(self):
        """Verwijdert de opgeslagen actieve LP-positie (bij het sluiten ervan)."""
        async with self._pool.acquire() as conn:
            await conn.execute("DELETE FROM active_lp_position")

    async def log_reflex_entry(self, regime: str, entry_price: float,
                                 entry_combined_score: float) -> int:
        """
        Legt het begin van een BULLISH_REFLEX/BEARISH_REFLEX-episode vast
        (27 aug 2026) -- geeft de nieuwe episode-id terug, die bij het
        uitstappen weer gebruikt wordt om dezelfde rij bij te werken.
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO reflex_episodes (regime, entry_price, entry_combined_score) "
                "VALUES ($1, $2, $3) RETURNING id",
                regime, entry_price, entry_combined_score,
            )
            return row["id"]

    async def log_reflex_exit(self, episode_id: int, exit_price: float, exit_reason: str):
        """
        Legt het einde van een reflex-episode vast, en berekent meteen het
        behaalde rendement (27 aug 2026) -- zodat we achteraf, zonder
        aparte berekening, kunnen zien of de overstap nuttig was.
        """
        async with self._pool.acquire() as conn:
            entry_row = await conn.fetchrow(
                "SELECT entry_price FROM reflex_episodes WHERE id = $1", episode_id
            )
            if not entry_row:
                return
            entry_price = entry_row["entry_price"]
            return_pct = ((exit_price - entry_price) / entry_price * 100) if entry_price else None

            await conn.execute(
                "UPDATE reflex_episodes SET exit_at = now(), exit_price = $1, "
                "exit_reason = $2, return_pct = $3 WHERE id = $4",
                exit_price, exit_reason, return_pct, episode_id,
            )

    async def save_regime_state(self, current_regime: str, trailing_entry_price: Optional[float],
                                  active_reflex_episode_id: Optional[int]):
        """
        Slaat de actuele regimestatus op (27 aug 2026) -- zodat de bot dit
        na een herstart correct kan herstellen, i.p.v. altijd terug te
        vallen op de default LP_MODE. Verwijdert eerst elke bestaande rij
        -- er hoort er maximaal een te zijn, net als bij active_lp_position.
        """
        async with self._pool.acquire() as conn:
            await conn.execute("DELETE FROM bot_regime_state")
            await conn.execute(
                "INSERT INTO bot_regime_state "
                "(current_regime, trailing_entry_price, active_reflex_episode_id) "
                "VALUES ($1, $2, $3)",
                current_regime, trailing_entry_price, active_reflex_episode_id,
            )

    async def get_regime_state(self) -> Optional[dict]:
        """Geeft de opgeslagen regimestatus terug, of None als er geen is."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT current_regime, trailing_entry_price, active_reflex_episode_id "
                "FROM bot_regime_state ORDER BY id DESC LIMIT 1"
            )
            return dict(row) if row else None

    async def get_daily_stats(self, date: Optional[str] = None) -> DailyStats:
        date = date or datetime.now().strftime("%Y-%m-%d")
        async with self._pool.acquire() as conn:
            trade_stats = await conn.fetchrow(
                """
                SELECT
                    COUNT(*) AS total,
                    COUNT(*) FILTER (WHERE status = 'success') AS successful,
                    COUNT(*) FILTER (WHERE status = 'failed') AS failed
                FROM trades
                WHERE created_at::date = $1::date
                """,
                date,
            )
            sentiment_stats = await conn.fetchrow(
                """
                SELECT
                    AVG(sentiment_score) FILTER (WHERE asset = 'BTC') AS avg_btc,
                    AVG(sentiment_score) FILTER (WHERE asset = 'HBAR') AS avg_hbar
                FROM sentiment_log
                WHERE created_at::date = $1::date
                """,
                date,
            )
            panic_count = await conn.fetchval(
                """
                SELECT COUNT(*) FROM strategy_signals
                WHERE panic_override_triggered = TRUE AND created_at::date = $1::date
                """,
                date,
            )

            return DailyStats(
                total_trades=trade_stats["total"] or 0,
                successful_trades=trade_stats["successful"] or 0,
                failed_trades=trade_stats["failed"] or 0,
                avg_btc_sentiment=float(sentiment_stats["avg_btc"] or 0.0),
                avg_hbar_sentiment=float(sentiment_stats["avg_hbar"] or 0.0),
                panic_overrides_triggered=panic_count or 0,
                # Netto HBAR/USDC-verandering vereist aggregatie over trades
                # met richting -- bewust als TODO gelaten, eenvoudig toe te
                # voegen zodra er echte trade-data is om tegen te valideren.
                net_hbar_change=0.0,
                net_usdc_change=0.0,
            )


if __name__ == "__main__":
    import asyncio

    async def structure_test():
        client = PostgresClient(dsn=os.environ.get("DATABASE_URL"))
        if not client.dsn:
            print("Geen DATABASE_URL gezet -- skip live verbindingstest.")
            print("Module-structuur (publieke methoden):")
            for name in dir(client):
                if not name.startswith("_"):
                    print(f"  - {name}")
            return
        try:
            await client.connect()
            print("Verbonden met Postgres.")
            await client.close()
        except Exception as e:
            print(f"Verbindingsfout (verwacht zonder live database): {e}")

    asyncio.run(structure_test())
