"""
postgres_client.py

Schrijft naar de tabellen uit db_schema.sql: sentiment_log,
strategy_signals, trades, open_positions. Asyncpg-gebaseerd, voor
gebruik in de asyncio-event-loop van main_orchestrator.py.
"""

import os
from datetime import datetime
from dataclasses import dataclass
from typing import Optional, List

import asyncpg


@dataclass
class DailyStats:
    total_trades: int
    successful_trades: int
    failed_trades: int
    avg_btc_sentiment: float
    avg_hbar_sentiment: float
    panic_overrides_triggered: int
    net_hbar_change: float
    net_usdc_change: float


class PostgresClient:
    def __init__(self, dsn: Optional[str] = None):
        self.dsn = dsn or os.environ.get("DATABASE_URL")
        self._pool: Optional[asyncpg.Pool] = None

    async def connect(self):
        if not self.dsn:
            raise EnvironmentError("DATABASE_URL niet gezet.")
        self._pool = await asyncpg.create_pool(self.dsn, min_size=1, max_size=5)

    async def close(self):
        if self._pool:
            await self._pool.close()

    async def log_sentiment(self, asset: str, headline: str, sentiment_score: float,
                              confidence: float, is_idiosyncratic: bool,
                              rationale: str = "", source: str = "llm") -> int:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO sentiment_log
                    (asset, headline, sentiment_score, confidence, is_idiosyncratic, rationale, source)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id
                """,
                asset, headline, sentiment_score, confidence, is_idiosyncratic, rationale, source,
            )
            return row["id"]

    async def log_strategy_signal(self, direction: str, confidence: float, position_fraction: float,
                                    btc_score: float, hbar_score: float,
                                    panic_override_triggered: bool = False, reasoning: str = "") -> int:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO strategy_signals
                    (direction, confidence, position_fraction, btc_score, hbar_score,
                     panic_override_triggered, reasoning)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id
                """,
                direction, confidence, position_fraction, btc_score, hbar_score,
                panic_override_triggered, reasoning,
            )
            return row["id"]

    async def log_trade(self, direction: str, engine: str, network: str, amount_in: float,
                          estimated_amount_out: Optional[float], actual_amount_out: Optional[float],
                          tx_hash: Optional[str], status: str,
                          strategy_signal_id: Optional[int] = None) -> int:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO trades
                    (direction, engine, network, amount_in, estimated_amount_out,
                     actual_amount_out, tx_hash, status, strategy_signal_id)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                RETURNING id
                """,
                direction, engine, network, amount_in, estimated_amount_out,
                actual_amount_out, tx_hash, status, strategy_signal_id,
            )
            return row["id"]

    async def open_position(self, entry_price: float, initial_stop_loss: Optional[float],
                              trailing_distance_pct: Optional[float], quantity_hbar: float,
                              trade_id: Optional[int] = None) -> int:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO open_positions
                    (entry_price, initial_stop_loss, trailing_distance_pct,
                     highest_price_seen, quantity_hbar, trade_id, is_open)
                VALUES ($1, $2, $3, $1, $4, $5, TRUE)
                RETURNING id
                """,
                entry_price, initial_stop_loss, trailing_distance_pct, quantity_hbar, trade_id,
            )
            return row["id"]

    async def update_highest_price(self, position_id: int, highest_price: float):
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE open_positions SET highest_price_seen = $1 WHERE id = $2",
                highest_price, position_id,
            )

    async def close_position(self, position_id: int):
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE open_positions SET is_open = FALSE, closed_at = now() WHERE id = $1",
                position_id,
            )

    async def get_open_positions(self) -> List[dict]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM open_positions WHERE is_open = TRUE")
            return [dict(r) for r in rows]

    async def get_daily_stats(self, date: Optional[str] = None) -> DailyStats:
        date = date or datetime.now().strftime("%Y-%m-%d")
        async with self._pool.acquire() as conn:
            trade_stats = await conn.fetchrow(
                """
                SELECT
                    COUNT(*) AS total,
                    COUNT(*) FILTER (WHERE status = 'success') AS successful,
                    COUNT(*) FILTER (WHERE status = 'failed') AS failed
                FROM trades
                WHERE created_at::date = $1::date
                """,
                date,
            )
            sentiment_stats = await conn.fetchrow(
                """
                SELECT
                    AVG(sentiment_score) FILTER (WHERE asset = 'BTC') AS avg_btc,
                    AVG(sentiment_score) FILTER (WHERE asset = 'HBAR') AS avg_hbar
                FROM sentiment_log
                WHERE created_at::date = $1::date
                """,
                date,
            )
            panic_count = await conn.fetchval(
                """
                SELECT COUNT(*) FROM strategy_signals
                WHERE panic_override_triggered = TRUE AND created_at::date = $1::date
                """,
                date,
            )

            return DailyStats(
                total_trades=trade_stats["total"] or 0,
                successful_trades=trade_stats["successful"] or 0,
                failed_trades=trade_stats["failed"] or 0,
                avg_btc_sentiment=float(sentiment_stats["avg_btc"] or 0.0),
                avg_hbar_sentiment=float(sentiment_stats["avg_hbar"] or 0.0),
                panic_overrides_triggered=panic_count or 0,
                # Netto HBAR/USDC-verandering vereist aggregatie over trades
                # met richting -- bewust als TODO gelaten, eenvoudig toe te
                # voegen zodra er echte trade-data is om tegen te valideren.
                net_hbar_change=0.0,
                net_usdc_change=0.0,
            )


if __name__ == "__main__":
    import asyncio

    async def structure_test():
        client = PostgresClient(dsn=os.environ.get("DATABASE_URL"))
        if not client.dsn:
            print("Geen DATABASE_URL gezet -- skip live verbindingstest.")
            print("Module-structuur (publieke methoden):")
            for name in dir(client):
                if not name.startswith("_"):
                    print(f"  - {name}")
            return
        try:
            await client.connect()
            print("Verbonden met Postgres.")
            await client.close()
        except Exception as e:
            print(f"Verbindingsfout (verwacht zonder live database): {e}")

    asyncio.run(structure_test())
