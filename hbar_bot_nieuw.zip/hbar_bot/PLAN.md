# HBAR Trading Bot — Projectplan

## ⚠️ PIVOT (22 aug 2026) — sentiment naar LLM, deployment naar Docker

Na analyse van een extern Gemini-gesprek over nieuwsbronnen en LLM-architectuur
is besloten:

1. **Sentiment-analyse**: naast (niet per se ter vervanging van) de vote/tijd-
   gewogen berekening in `cryptopanic_client.py`, gebruikt de bot nu ook een
   **LLM-gebaseerde sentiment-engine** (`llm_sentiment_engine.py`, Claude Haiku
   4.5 met gedwongen JSON-output via tool-use). Reden: rijker contextbegrip
   (bv. "Google Cloud breidt Hedera-nodes uit" correct wegen), tegen hogere
   latency/kosten dan pure vote-counting. Claude i.p.v. Gemini's voorstel
   (GPT-4o-mini) omdat je al met Claude werkt.
2. **Deployment**: van losse Python-scripts naar **Docker Compose +
   PostgreSQL** (`docker-compose.yml`, `Dockerfile`, `db_schema.sql`).
   Automatisch herstarten bij crash (`restart: always`), robuuste opslag
   van trades/sentiment/posities i.p.v. losse logs.
3. **Lokaal LLM op de VPS is bewust afgewezen** — geanalyseerd en verworpen:
   geen GPU op de VPS betekent 3-8s latency per nieuwsbericht (te traag voor
   een reactieve bot), tegenover 0.2-0.5s bij een cloud-API die bovendien
   maar een fractie van een cent per call kost.
4. **Farm/epoch-weight-optimalisatie (welke pool het meest oplevert aan
   SAUCE-farming-rewards) is expliciet uit scope gezet** — vereist details
   uit SaucerSwap's API-docs die nog niet zijn aangeleverd (auth-methode,
   endpoint voor epoch-gewichten). Terugkomen zodra die info er is.
5. **CORRECTIE (22 aug 2026): SaucerSwap V3 bestaat wél.** Eerder in dit
   project kon ik geen V3 vinden via GitHub-onderzoek — terecht op dat
   moment, want V3 is geen open-source AMM-contract maar een **off-chain
   matching-engine met on-chain settlement** (CLOB, sinds 12 juni 2026
   live op mainnet), die dus niet in de publieke SaucerSwap-GitHub-org
   staat. Bovendien ligt de launch-datum ná mijn kennis-cutoff (jan 2026).
   Zie de nieuwe sectie hieronder voor wat dit betekent voor onze
   architectuur.

## Complete architectuur — de datastroom

```
┌─────────────────────────────────────────────────────────────────────┐
│                         1. DATA-INGESTIE                            │
│  cryptopanic_client.py    coingecko_client.py                       │
│  (BTC + HBAR nieuws)      (prijzen, 90d beta/correlatie)             │
└──────────────┬───────────────────────┬──────────────────────────────┘
               │                       │
               ▼                       │
┌─────────────────────────────┐        │
│   2. SENTIMENT-LAAG          │       │
│  ┌─────────────────────────┐│        │
│  │ cryptopanic_client.py    ││        │
│  │ (regelgebaseerd: tijds-  ││        │
│  │  verval + votes)         ││        │
│  └─────────────────────────┘│        │
│  ┌─────────────────────────┐│        │
│  │ llm_sentiment_engine.py  ││        │
│  │ (Claude Haiku 4.5,       ││        │
│  │  gedwongen JSON-output)  ││        │
│  └─────────────────────────┘│        │
└──────────────┬───────────────┘       │
               │  btc_score, hbar_score │  hbar_btc_beta
               ▼                       ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    3. STRATEGY_ENGINE.PY                            │
│   BTC leidend (default trigger) + HBAR-specifiek als modifier/      │
│   losstaande trigger. Combinatiematrix bepaalt richting+confidence. │
└──────────────────────────────┬────────────────────────────────────────┘
                                │ SignalResult (direction, confidence, position_fraction)
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   4. SAFETY_OVERRIDE.PY                             │
│   Circuit breaker: vaste 40/60-weging (Gemini-model). Forceert      │
│   ALLEEN een volledige exit bij extreme paniek, nooit een koop.     │
└──────────────────────────────┬────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│              5. RISK_MANAGER.PY  (nog te bouwen)                    │
│   Max trades/dag, daily loss-limit, harde guardrails los van        │
│   de strategie zelf. Kan een signaal blokkeren, nooit versterken.   │
└──────────────────────────────┬────────────────────────────────────────┘
                                │
                 ┌──────────────┴──────────────┐
                 ▼                             ▼
    ┌───────────────────────┐      ┌─────────────────────────────┐
    │   HOLD-signaal         │      │   BUY / SELL-signaal          │
    │  ┌───────────────────┐│      │  ┌─────────────────────────┐│
    │  │ lp_manager.py      ││      │  │ position_planner.py      ││
    │  │ (V2 CLMM-positie   ││      │  │ (VIX Rider-patroon:      ││
    │  │  rond huidige prijs,│      │  │  entry/stop-loss/        ││
    │  │  herbalanceren bij  │      │  │  trailing-stop, €2000)   ││
    │  │  out-of-range)      ││      │  └────────────┬────────────┘│
    │  └───────────────────┘│      │               ▼               │
    │  Eerst LP intrekken bij│      │  ┌─────────────────────────┐│
    │  sterk signaal, dan pas│      │  │ execute_hbar_swap_       ││
    │  swappen               │      │  │ standalone.py            ││
    │                        │      │  │ (losgekoppeld subprocess,││
    │                        │      │  │  V1 of V2 engine)        ││
    │                        │      │  └────────────┬────────────┘│
    └───────────────────────┘      └───────────────┬──────────────┘
                                                     │
                                                     ▼
                                    ┌─────────────────────────────┐
                                    │  swap_executor.py (V1)       │
                                    │  swap_executor_v2.py (V2)    │
                                    │  hedera_rpc_client.py         │
                                    │  → Hedera mainnet/testnet     │
                                    └────────────┬────────────────┘
                                                 │
                                                 ▼
                              ┌───────────────────────────────────┐
                              │  6. LOGGING & NOTIFICATIES          │
                              │  postgres_client.py (nog te bouwen) │
                              │  → sentiment_log, strategy_signals, │
                              │    trades, open_positions            │
                              │  telegram_notify.py ✅               │
                              │  → report_trade, report_panic_       │
                              │    override, report_lp_rebalance,    │
                              │    report_error, send_daily_summary  │
                              └───────────────────────────────────┘
```

**Alles wordt aangestuurd door `main_orchestrator.py` (nog te bouwen)** — de
event-loop die stap 1 t/m 6 elke cyclus doorloopt. Belangrijk architectuur-
principe: **het LLM belt nooit rechtstreeks naar de VPS om te traden** — de
orchestrator roept het LLM aan voor een score, en beslist daarna zelf via
de eigen guardrails (strategy_engine → safety_override → risk_manager) of
en hoe er gehandeld wordt.

## SaucerSwap V3 (CLOB) — nieuw ontdekt, nog niet geïntegreerd

Live op mainnet sinds 12 juni 2026, geaudit door Halborn (18 mei 2026).
Fundamenteel ander mechanisme dan V1/V2:

- **Order signeren i.p.v. transactie signeren**: EIP-712 typed data of
  Hedera personal-sign. Tokens blijven in de wallet tot een fill (wel
  eenmalig een token-allowance nodig per token).
- **Off-chain matching, on-chain settlement**: een matching-engine
  (closed-source, off-chain) matcht orders met milliseconde-latency;
  gematchte orders settlen atomisch via een on-chain "reactor"-contract.
- **Order-types**: limit, market, maker-only (post-only, neemt nooit
  liquiditeit af), en OCO (one-cancels-the-other).
- **Geen gas voor plaatsen/annuleren** — alleen fees bij daadwerkelijke
  fills.
- **AMM-backstop**: een V3-order kan opt-in doorroutet worden naar V1/V2
  als het orderboek zelf onvoldoende diepte heeft (eenrichtingsverkeer,
  geen prijsvergelijking tussen venues).
- **Markt-status**: elke markt heeft zowel een `status`-veld als een
  losse `isMarketHalted`-vlag — een markt kan "open" tonen terwijl
  matching gehalt is. **Beide checken vóór het plaatsen van een order.**
- **Belangrijk risico**: getoonde orderstatus kan kort afwijken van de
  daadwerkelijke on-chain staat (asynchrone matching/settlement) — zie
  de V3 Orderbook Risk Notice voor het volledige risico-overzicht
  voordat hier ooit mee gehandeld wordt.

### Wat dit voor onze architectuur zou kunnen betekenen

- Mogelijk **relevanter voor de LP-vervangende rol** dan voor de kern-
  swap: een maker-only limit-order op je gewenste prijs is in essentie
  een eenvoudiger alternatief voor `lp_manager.py`'s concentrated-
  liquidity-positie, zonder impermanent-loss-risico (je token beweegt
  niet totdat er een fill is).
- De eerder genoemde SaucerSwap-authenticatie-API (waar dit gesprek
  ooit mee begon) is vermoedelijk deze Orderbook API, niet een read-only
  data-API zoals ik toen aannam.
- **Nog niet geïntegreerd** — de "Orderbook API reference" (exacte
  endpoints, auth-methode, request-schema's voor het signeren van orders)
  is niet in de aangeleverde documentatie opgenomen. Ik kan
  `docs.saucerswap.finance` nog steeds niet zelf bereiken vanuit deze
  sandbox. Nodig voordat ik hier code voor bouw: de Orderbook API
  reference-pagina en de V3 Orderbook Risk Notice.



Sentiment-gedreven trading bot voor SaucerSwap (Hedera), die HBAR<->USDC
swapt op basis van BTC- en HBAR-specifiek nieuwssentiment. Geïnspireerd
op de bestaande Touch & Turn Scalper / VIX Rider-architectuur (losgekoppelde
subprocessen, risk-first design).

## Kernprincipe sentiment-logica

BTC-sentiment is de **leidende/default trigger** (hoog nieuwsvolume, HBAR
volgt doorgaans de brede markt). HBAR-specifiek nieuws werkt als **modifier**
op die basis-trade, en kan als **losstaande trigger** dienen wanneer BTC
geen duidelijke beweging laat zien (bv. een nieuwe Hedera Council-member).
Zie `strategy_engine.py` voor de volledige combinatiematrix.

Een aparte, simpelere vaste-weging-berekening (BTC 40% / HBAR 60%, uit een
extern geraadpleegd Gemini-gesprek) dient als **paniek-circuit-breaker**
bovenop deze primaire logica — zie `safety_override.py`. Deze overschrijft
alleen richting SELL bij extreme paniek, nooit richting BUY.

## Status per module

| Module | Status | Beschrijving |
|---|---|---|
| `cryptopanic_client.py` | ✅ Klaar | BTC + HBAR nieuws-ophalen, tijdsgewogen sentiment-score (regelgebaseerd) |
| `llm_sentiment_engine.py` | ✅ Klaar (structuur) | LLM-gebaseerde sentiment-analyse via Claude, gedwongen JSON-schema |
| `coingecko_client.py` | ✅ Klaar | Dynamische HBAR/BTC-beta, 90-dagen rolling window |
| `strategy_engine.py` | ✅ Klaar | Primaire beslislogica (BTC leidend, HBAR modifier) |
| `safety_override.py` | ✅ Klaar | Paniek-circuit-breaker (vaste 40/60-weging) |
| `position_planner.py` | ✅ Klaar | VIX Rider-patroon vertaald: entry/stop-loss/trailing-stop, €2000 kapitaal |
| `hedera_address_utils.py` | ✅ Klaar | Hedera-ID ↔ EVM-adres conversie (geverifieerd via round-trip test) |
| `hedera_rpc_client.py` | ✅ Klaar | Wallet, tx-signing, verbinding met Hedera EVM-laag |
| `config.py` | ✅ Klaar | Testnet + mainnet V1-adressen compleet; **mainnet V2-adressen nog leeg** |
| `swap_executor.py` | ✅ Klaar | SaucerSwap V1 (klassieke AMM) swap-uitvoering |
| `swap_executor_v2.py` | ✅ Klaar | SaucerSwap V2 (CLMM) swap-uitvoering via `exactInputSingle` |
| `execute_hbar_swap_standalone.py` | ✅ Klaar | Losgekoppeld subprocess-patroon (VIX Rider-stijl), ondersteunt V1 en V2 |
| `verify_setup.py` | ✅ Klaar | Read-only verificatiescript (geen transacties, geen kosten) |
| `Dockerfile` / `docker-compose.yml` | ✅ Klaar | Deployment: bot + PostgreSQL, auto-restart bij crash |
| `db_schema.sql` | ✅ Klaar | Tabellen voor sentiment_log, strategy_signals, trades, open_positions |
| `.env.example` | ✅ Klaar | Alle benodigde environment-variabelen |
| `lp_manager.py` | ✅ Klaar | V2 CLMM-positiebeheer HBAR/USDC; tokenId-parsing (via Transfer-event) en liquidity-ophalen (via positions()) afgerond 23 aug |
| `postgres_client.py` | ⏳ Nog te bouwen | Python-laag die schrijft naar de nieuwe Postgres-tabellen |
| `risk_manager.py` | ⏳ Nog te bouwen | Max trades/dag, daily loss-limit, harde guardrails los van strategie |
| `main_orchestrator.py` | ⏳ Nog te bouwen | Event loop: poll → sentiment (LLM + vote-based) → strategie → risk-check → swap → Postgres-log |
| `telegram_notify.py` | ✅ Klaar | Trade-meldingen, LP-rebalance-meldingen, foutmeldingen, dagelijkse samenvatting |
| `backtest_pipeline.py` | ✅ Klaar (mechaniek), data ontbreekt nog | Lookahead-bias-vrije terugtoets van sentiment-regels tegen historisch nieuws + koersen |
| **`lp_manager.py`** | 🔜 **Later, bewust uitgesteld** | Actief LP-beheer in V2 concentrated liquidity pool tijdens rustige/neutrale sentiment-periodes |

## De LP-module (uitgesteld, hier vastgelegd voor later)

Concept uit het Gemini-gesprek, nog niet gebouwd:

- Bij een **HOLD**-signaal van de strategy_engine (in plaats van niets doen):
  open een smalle liquiditeitspositie rond de huidige prijs via
  `NonfungiblePositionManager.mint()` (V2 CLMM)
- Monitor of de prijs uit de ingestelde marge loopt → zo ja:
  `decreaseLiquidity()` + `collect()`, herbalanceren, nieuwe positie
  rond de nieuwe prijs
- Bij een sterk sentiment-signaal (BUY/SELL of paniek-override):
  **eerst LP-positie intrekken**, dan pas de swap uitvoeren — anders
  zit kapitaal vast in de pool tijdens een crash
- Open vragen voor als we dit oppakken: breedte van de prijsmarge (bv.
  ±5%), rebalance-trigger-drempel, tick-math-berekeningen voor V2

Dit voegt een aanzienlijk nieuw risico toe (impermanent loss) en vereist
tick-math die we nog niet hebben uitgewerkt — bewust uitgesteld tot de
kernbot (swap-only) end-to-end getest is.

## Openstaande blokkades voor live gebruik

1. **Mainnet V2-adressen** (Factory, SwapRouter, QuoterV2, PositionManager)
   nog niet aangeleverd — nodig voor `config.py`
2. **Fee-tier verificatie** — huidige aanname 3000 (0.3%) moet gecheckt
   worden tegen de daadwerkelijke HBAR/USDC-pool
3. **USDC-associatie** op het bot-account — nog te bevestigen
4. **Testnet-HBAR-balans** op het bot-account — nog te bevestigen

~~5. lp_manager.py: tokenId/liquidity-placeholders~~ — **AFGEVINKT (23 aug 2026)**:
tokenId wordt nu geparsed uit het Transfer-event van de mint-transactie,
en `close_position()` haalt de actuele liquidity op via `positions(tokenId)`
i.p.v. een aangenomen waarde.

## Expliciet uitgesteld (niet vergeten, wel bewust niet nu)

- **Farm/epoch-weight-optimalisatie**: welke pool het meest oplevert aan
  SAUCE-farming-rewards. Vereist SaucerSwap API-details (auth-methode,
  endpoint-structuur) die nog niet zijn aangeleverd. Terugkomen zodra
  die info beschikbaar is.

## Gefaseerd validatietraject (22 aug 2026)

Backtesting en een live testnet-periode zijn geen alternatieven voor
elkaar, maar opeenvolgende fases met een verschillend doel:

**Fase 1 — Backtesting (snel, statistisch).** `backtest_pipeline.py`
tegen een jaar historisch nieuws + Binance-koersen. Doel: bewijzen dat
het sentiment-signaal überhaupt voorspellende waarde heeft, en de
drempelwaarden in `strategy_engine.py` kalibreren. Kan in een middag
draaien; risico is overfitten op het verleden.

**Fase 2 — Testnet-maand (langzaam, operationeel).** `main_orchestrator.py`
laten draaien op testnet, ononderbroken, minstens een maand. Doel:
bewijzen dat het complete systeem betrouwbaar draait onder echte
marktomstandigheden — crasht de bot niet, werkt de swap-executie zoals
verwacht, hoe gedraagt de Hedera-RPC-verbinding zich in de praktijk.
Kan geen overfitting-risico wegnemen (één maand is een kleine
steekproef aan signalen), maar dekt operationele risico's af die
backtesting niet kan raken.

**Fase 3 — Mainnet, klein bedrag.** Pas na een succesvolle Fase 1 én
Fase 2, startend met een fractie van de €2.000.

**Consequentie**: Fase 2 kan pas beginnen zodra `main_orchestrator.py`
en `risk_manager.py` bestaan — er is nog geen doorlopend proces om een
maand te laten draaien. Dit is dus de directe aanleiding om die twee nu
te bouwen.

## Dubbele rol van de bot: directioneel traden + LP-beheer (22 aug 2026)

De bot doet nu twee dingen **gelijktijdig**, niet meer sequentieel
(LP alleen tijdens HOLD zoals oorspronkelijk):
1. Realtime directioneel traden op nieuws/sentiment (de live cyclus)
2. Realtime de HBAR/USDC-LP-positie bijsturen om impermanent loss te
   voorkomen — proactief op sentiment-richting, adaptief qua breedte
   op volatiliteits-regime

**CORRECTIE (22 aug 2026)**: geen gedeelde 50/50-kapitaalsplit meer.
LP-beheer en directioneel traden draaien als **volledig onafhankelijke
processen**, elk met hun eigen apart geconfigureerde kapitaal (bv. losse
wallets/instellingen). `risk_manager.py` bemoeit zich uitsluitend met
het directionele traden (dedup, cooldown, max trades/dag, daily
loss-limit) en heeft een eigen `trading_capital_usdc`-instelling, niet
afgeleid van een gedeeld totaal. `lp_manager.py` beheert zijn eigen
kapitaal volledig zelfstandig.

**`lp_manager.py` uitgebreid** met:
- `VolatilityRegime` (LOW/NORMAL/HIGH) → bepaalt range-breedte (3%/5%/12%),
  periodiek te verversen (niet continu) op basis van rolling volatiliteit
- Sentiment-gestuurde asymmetrische range-verschuiving (proactief, i.p.v.
  alleen reactief herbalanceren als de prijs al buiten de marge is)
- Een cooldown (baseline 4 uur) die beide triggers (reactief + proactief)
  bindt, zodat ze elkaar niet kunnen opjagen tot overmatig herbalanceren

**Openstaand — LP-parameters leren uit historische data**: gedeeltelijk
opgelost (22 aug 2026). `geckoterminal_client.py` is gebouwd en haalt
historische pool-OHLCV **inclusief volume per candle** op via
GeckoTerminal's gratis publieke API — precies de databehoefte die
hiervoor ontbrak. Bevestigd, echt WHBAR/USDC V2-poolcontract
(`0xc5b707348da504e9be1bd4e21525459830e7b11d`, $3.2M TVL, $2.7M
24u-volume op 22 aug 2026) toegevoegd aan `config.py`. Nog te bouwen:
de daadwerkelijke LP-parameter-backtest-loop die deze data gebruikt om
`cooldown_seconds` en de regime-breedtes te optimaliseren — de databron
staat er nu, de simulatie zelf nog niet. Dezelfde bron kan mogelijk ook
de eerder uitgestelde farm/epoch-weight-vraag beantwoorden.

## De drie kernmodules zijn gebouwd (22 aug 2026)

`risk_manager.py`, `postgres_client.py`, en `main_orchestrator.py` staan
er nu, alle drie getest. Kanttekening: `main_orchestrator.py` bevat vier
bewuste TODO's die eerst opgelost moeten worden voordat dit live kan:

1. Live prijs-quote i.p.v. de huidige placeholder (0.065) voor de
   positiegrootte-berekening
2. `lp_manager`-koppeling aan de V1/V2-contractadressen uit `config.py`
   (staat nu op `None`)
3. Correcte token0/token1-verdeling bij het openen van een LP-positie
   (nu een grove helft/helft-placeholder)
4. Periodieke (niet elke cyclus) herberekening van het volatiliteits-
   regime uit historische GeckoTerminal-data (draait nu altijd op NORMAL)

## PIVOT: RegimeOrchestrator vervangt drie processen (23 aug 2026)

Op verzoek: bij "groot nieuws" moet de bot de LP-pool leeghalen en
alles omzetten naar HBAR (bullish) of USDC (bearish), om maximaal te
profiteren van een koersbeweging; bij rustig nieuws moet het volledige
kapitaal juist in de pool staan voor yield.

**Nieuwe module**: `regime_orchestrator.py` — alles-of-niets schakelaar
tussen drie toestanden (`LP_MODE`, `BULLISH_REFLEX`, `BEARISH_REFLEX`),
getriggerd door dezelfde vaste 40/60-weging als `safety_override.py`
(`compute_fixed_combined_score`), nu SYMMETRISCH toegepast (niet alleen
paniek naar beneden, ook euforie naar boven). Winst nemen uit een
bullish-reflex gebeurt via `TrailingStopTracker` -- exact hetzelfde
piek-detectie-mechanisme als bij de reguliere directionele trades.

**Kapitaal samengevoegd**: de eerdere 50/50-scheiding tussen LP- en
trading-kapitaal is losgelaten -- het volledige bedrag (nu €2.000,
`REGIME_TOTAL_CAPITAL_USDC`) wordt door één proces beheerd.

**Drie processen vervangen door één**: `TradingOrchestrator`,
`LpOrchestrator`, en `PositionMonitorOrchestrator` zijn uit de actieve
`asyncio.gather()` in `main_orchestrator.py` gehaald. De klassen zelf
blijven wél in het bestand staan (niet verwijderd) -- bewuste keuze,
voor het geval een apart, gegradueerd tradingbudget met
`strategy_engine.py`'s combinatiematrix ooit weer gewenst is naast dit
regime-kapitaal. `strategy_engine.py` en `position_planner.py` blijven
dus bestaan en correct werken, maar worden momenteel nergens
aangeroepen vanuit de live loop.

**Bewuste afweging**: de eerdere `LpOrchestrator` paste de LP-range-
breedte aan op basis van een volatiliteits-regime en verschoof de range
proactief op sentiment. `RegimeOrchestrator`'s LP_MODE doet dit
(nog) niet -- de positie wordt simpelweg geopend en blijft staan tot een
regime-overgang. Reden: bij een regime-schakelaar verlaat je de pool
sowieso zodra het echt volatiel wordt (dat IS de bullish/bearish-reflex),
dus de noodzaak voor actief impermanent-loss-beheer tijdens LP_MODE is
kleiner dan in het oude, permanent-actieve LP-model.

**NABOUW-FIX (23 aug 2026, later dezelfde dag)**: de pivot brak
stilzwijgend de koppeling met het zelf-herkalibratie-systeem van de dag
ervoor. `TradingOrchestrator` (nu inactief) was de enige die naar
`sentiment_log` schreef; `recalibrate_from_live_history.py` leest daar
juist uit. Zonder fix zou de nachtelijke cron tegen een niet-groeiende
tabel aanlopen en nooit meer iets nieuws vinden. Opgelost: 
`RegimeOrchestrator._refresh_sentiment_if_due()` logt nu ook elke losse
headline-score naar `sentiment_log`, getest en bevestigd (2 aanroepen
voor 2 assets, dedup werkt correct). Ook cooldown tegen "flapping"
(`REGIME_COOLDOWN_SECONDS`, standaard 30 min, met uitzondering voor
winst-name via de trailing-stop) en trade-logging naar `trades` zijn
toegevoegd.

**NABOUW-FIX 2 (23 aug 2026, nog later dezelfde dag)**: `_execute_transition`
zette voorheen `self.current_regime` onvoorwaardelijk op de doel-regime,
ongeacht of de onderliggende swap(s) daadwerkelijk slaagden. Bij een
mislukte swap (netwerkfout, slippage, te weinig gas) zou de bot dus zijn
geregistreerde staat verliezen t.o.v. de werkelijke on-chain positie --
bij echt geld een serieus risico. Opgelost: `_execute_transition` geeft
nu een succes/faal-boolean terug; `current_regime` wordt alleen
bijgewerkt bij succes, en bij falen gaat er een expliciete "HANDMATIGE
CONTROLE VEREIST"-melding naar Telegram. Getest en bevestigd met een
gesimuleerde mislukte swap.

**NABOUW-FIX 3 (23 aug 2026)**: bij het heropenen van de LP-positie
(terugkeer naar LP_MODE) gebruikte de kapitaalberekening hardcoded
`1e6`/`1e8` voor USDC/HBAR-decimalen, in plaats van de al eerder
ontdekte, correcte waarden (testnet-USDC-testtoken heeft 18 decimalen,
niet 6 -- zie de eerdere GeckoTerminal/config.py-ontdekking). `_setup_lp_manager()`
haalde `base.usdc_decimals` al correct op, maar sloeg het nooit op als
instantie-attribuut. Resultaat: een factor 10¹² fout in het bedrag dat
naar de LP-positie zou gaan op testnet. Opgelost: `self._usdc_decimals`
en `self._hbar_decimals` worden nu bewaard en gebruikt in de
berekening. Getest en het factor-verschil expliciet aangetoond.

**NABOUW-FIX 4 (23 aug 2026, meest impactvolle fix van vandaag)**: bij
het verlaten van `BULLISH_REFLEX` werd het te swappen HBAR-bedrag
herberekend als `total_capital_usdc / current_price` -- maar de
werkelijk bezeten hoeveelheid HBAR was vastgesteld bij de INSTAPPRIJS,
niet de huidige prijs. Bij een koersstijging (het scenario waar de hele
reflex voor bedoeld is) bleef hierdoor een deel van de HBAR-positie
stelselmatig ongebruikt liggen -- de koerswinst werd dus nooit verzilverd.
Cijfervoorbeeld uit de test: bij een stijging van 0.070 naar 0.085 bleef
17,6% van de positie (~5.042 HBAR) achter. Hetzelfde gold voor de
LP_MODE-herbalancering, en voor alle overgangen die volgen op het sluiten
van een LP-positie (die geeft een MIX van HBAR+USDC terug, niet zuiver
één token). Opgelost: alle overgangen gebruiken nu de WERKELIJKE
on-chain balans (`_get_swappable_hbar_balance()`,
`_get_swappable_usdc_balance()`), met een vaste gas-reserve (5 HBAR).
Getest en het verschil cijfermatig aangetoond.

**NABOUW-FIX 5 (23 aug 2026, op verzoek)**: de gas-reserve
(`GAS_RESERVE_HBAR = 5.0`) was een vast HBAR-bedrag, terwijl Hedera's
transactiekosten in USD-termen zijn vastgesteld (fee-schedule) maar in
HBAR worden betaald. Bij een lage HBAR-prijs zou 5 HBAR te weinig kunnen
dekken, bij een hoge prijs onnodig veel kapitaal inactief laten liggen.
Opgelost: `GAS_RESERVE_USD = 2.0`, omgerekend naar HBAR op basis van de
actuele prijs (`GAS_RESERVE_USD / current_price`). Getest bij vier
verschillende prijzen ($0.01-$2.00) -- de HBAR-reserve schaalt correct
mee, de USD-waarde blijft constant.

**Ondergrens toegevoegd (op verzoek)**: `MIN_GAS_RESERVE_HBAR = 10.0` --
de reserve is nu het grootste van de USD-som en deze vaste ondergrens,
zodat er bij een hoge HBAR-prijs nooit minder dan 10 HBAR wordt
achtergehouden. Getest bij dezelfde vier prijzen: bij $0.50 en $2.00
springt de ondergrens correct in (10 HBAR i.p.v. de lagere USD-som).

**NABOUW-FIX 6 (23 aug 2026)**: als `DRY_RUN=false` staat maar
`HEDERA_BOT_PRIVATE_KEY` per ongeluk ontbreekt (`self.rpc_client` is dan
`None`), gaven de balans-functies `0.0` terug. Bij bedrag 0 werd de swap
overgeslagen door de `amount>0`-guards, en de code interpreteerde dat als
succes -- de bot zou zichzelf dan valselijk als "overgang geslaagd"
registreren, inclusief een misleidende Telegram-bevestiging, terwijl er
geen wallet was aangesloten en er dus niets was gebeurd. Opgelost: een
expliciete guard vooraan `_execute_transition` die dit scenario direct
en duidelijk laat falen. Getest en bevestigd: `current_regime` blijft nu
correct ongewijzigd i.p.v. valselijk bijgewerkt.

## Code-verificatieronde 2: lp_manager.py (23 aug 2026)

Op verzoek verder gezocht naar dezelfde bug-categorie (staat-
inconsistentie, decimalen-aannames) in andere kernmodules. Gevonden in
`lp_manager.py`'s `rebalance_if_needed()`: na `close_position()` wordt
`open_position()` aangeroepen met de oorspronkelijk MEEGEGEVEN
`amount0`/`amount1`-parameters, niet de werkelijke balans die uit de
sluiting terugkwam (inclusief opgebouwde fees en een mogelijk andere
token-verhouding door prijsbeweging binnen de oude range) -- zelfde
categorie fout als de vijfde `regime_orchestrator.py`-fix van vandaag.

**Bewust NIET gefixt, wel gedocumenteerd**: dit codepad zit in
`LpOrchestrator` (de klasse die sinds de `RegimeOrchestrator`-pivot
NERGENS meer wordt aangeroepen -- bevestigd via `grep`). Een echte fix
vereist weten of `mint()` een voorafgaande WHBAR-ERC20-`approve()`
verwacht, of native HBAR via `msg.value` intern wrapt -- dat bepaalt
welke balans-functie je moet gebruiken. Dit kon niet met zekerheid
worden geverifieerd tegen het daadwerkelijke contract, dus is een gok
hier bewust vermeden (zelfde principe als bij de contractadressen
eerder in dit project). Vastgelegd als expliciete waarschuwing in de
code zelf, zodat een eventuele toekomstige heractivatie van
`LpOrchestrator` deze bug niet stilzwijgend meeneemt.

## KRITIEKE BEVINDING: geen WHBAR/USDC-testnet-pool (23 aug 2026)

Bij het testen van `swap_executor_v2.py` (aanleiding: een vermoeden dat
de HBAR-decimalen-conventie in de swap-code niet klopte -- 18 decimalen
via `to_wei("ether")` vs. de 8 decimalen die elders voor WHBAR worden
aangenomen) bleek een `quote_hbar_to_usdc()`-call op testnet consequent
te reverten, bij ALLE vier gangbare fee-tiers (100/500/3000/10000).

Rechtstreekse Factory-checks (`getPool()` voor V2, `getPair()` voor V1)
bevestigen: **er bestaat helemaal geen pool** voor WHBAR met ons huidige
testnet-USDC-token (`0.0.6503036`) -- niet in V1, niet in V2, bij geen
enkele fee-tier. Dit verklaart de reverts volledig, LOS van de
decimalen-vraag (die blijft dus feitelijk onbeslist, kon niet getest
worden zonder een bestaande pool).

**Waarschijnlijke oorzaak**: dat testnet-USDC-token kwam uit een losse
HashScan-zoekopdracht, niet uit SaucerSwap's eigen documentatie -- het
is vermoedelijk een los testtoken zonder ooit gekoppelde liquiditeit,
niet het token dat SaucerSwap zelf voor hun testnet-pools gebruikt.

**Vervolgstap, nog te doen door de gebruiker**: het daadwerkelijk actieve
HBAR/USDC-paar (of een ander actief paar als sanity-check) rechtstreeks
opzoeken in SaucerSwap's eigen testnet-app, en het bijbehorende
token-ID noteren -- in plaats van verder te gokken naar adressen.

Twee losse verificatiescripts gebouwd voor deze exercitie, beide
herbruikbaar zodra er een nieuw token-ID is: `verify_v2_pool_exists.py`,
`verify_v1_pool_exists.py`.

## UPDATE: officiële SaucerSwap-documentatie ontvangen (23 aug 2026)

Gebruiker leverde de officiële `docs.saucerswap.finance`-pagina's aan
("Contract deployments" en "Developer overview"). Belangrijke
consequenties:

- **Blokkade #1 (mainnet V2-adressen) OPGELOST**: `MAINNET_V2_IDS` in
  `config.py` bevatte tot nu toe alleen `None`-placeholders. Nu ingevuld
  met de officiële adressen: Factory `0.0.3946833`, SwapRouter
  `0.0.3949434`, QuoterV2 `0.0.3949424`, PositionManager `0.0.4053945`
  (de niet-gedeprecieerde V2-variant, niet `0.0.3949448`). Getest:
  resolvt correct naar geldige EVM-adressen.
- **Bevestigd, geen nieuwe actie nodig**: al onze bestaande testnet- en
  WHBAR-adressen kwamen exact overeen met deze officiële bron.
- **USDC bevestigd structureel afwezig**: SaucerSwap heeft zelf GEEN
  officieel USDC-testtoken in hun deployment-lijst -- de eerdere
  "geen pool"-bevinding is dus geen toeval, USDC is simpelweg niet
  onderdeel van hun officiële testnet-opzet. SAUCE is dat wel
  (gekoppeld aan Masterchef/Mothership).
- **"V2 aanbevolen voor nieuwe integraties, V1 is legacy"** -- bevestigt
  dat onze eerdere keuze voor V2 als primaire engine terecht was.
- **Officiële REST Data API ontdekt** (`test-api.saucerswap.finance`
  voor testnet) -- kan pool-data/prijzen/TVL rechtstreeks leveren,
  potentieel een vervanging voor onze eigen `getPool()`-zoektochten.
  Vereist een `x-api-key`, AAN TE VRAGEN bij het SaucerSwap-team zelf --
  niet direct bruikbaar, vastgelegd als toekomstige verbetering.

**Resterende blokkades, bijgewerkt**: van de oorspronkelijke vier is nu
alleen nog over: (2) fee-tier-verificatie, (3) USDC-associatie
[waarschijnlijk te vervangen door een ander token, zie hierboven], (4)
testnet/mainnet-HBAR-balans bevestigen. Mainnet V2-adressen zijn klaar.

## Concrete fixes uit de officiele SaucerSwap-docs (23 aug 2026)

Gebruiker leverde vier extra pagina's aan: WHBAR overview, V2
swap-quote, en V2 new-liquidity-position. Vier directe consequenties:

1. **Bevestigd**: "if the token is HBAR, no spender allowance is
   required" -- `swap_executor_v2.py`'s bestaande aanpak (native HBAR
   via `msg.value`, geen `approve()` voor de HBAR-kant) was al correct.

2. **NIEUWE vereiste ontdekt**: het bot-account moet vooraf
   geassocieerd zijn met het SaucerSwapV2 LP-NFT-token (mainnet
   `0.0.4054027`, testnet `0.0.1310436`) voordat `mint()` ooit kan
   slagen -- naast de al bekende USDC-associatie. Toegevoegd aan de
   blokkade-lijst.

3. **Foute fee-tier-lijst gecorrigeerd**: de docs noemen expliciet
   500/1500/3000/10000 als geldige V2-tiers -- wij testten met
   100/500/3000/10000 (100 is ongeldig, 1500 ontbrak). Gecorrigeerd in
   alle drie de verificatiescripts.

4. **KRITIEKE FIX in `lp_manager.py`'s `open_position()`**: het
   officiele patroon is `multicall([mint_encoded, refundETH_encoded])`
   met de HBAR-kant als `payableAmount`/`msg.value` -- onze code riep
   `mint()` voorheen RECHTSTREEKS aan, zonder multicall, zonder ooit een
   payable-waarde mee te sturen (`build_and_send_transaction()` zette
   `value` nergens). Zonder deze fix zou `mint()` altijd falen zodra er
   een echte WHBAR-pool is, want het contract ontvangt nooit de HBAR die
   het intern moet wrappen. Opgelost:
   - `hedera_rpc_client.py`: `build_and_send_transaction()` heeft nu een
     `value_wei`-parameter.
   - `lp_manager.py`: `LpPositionConfig` heeft een nieuw
     `whbar_address`-veld (betrouwbare detectie welke kant HBAR is, i.p.v.
     een positionele aanname). `open_position()` gebruikt nu het
     multicall-patroon en berekent de juiste payable-waarde.
   - `regime_orchestrator.py`: geeft `whbar_address` door bij het
     opbouwen van de LP-configuratie.
   - Getest: multicall/refundETH correct herkend in het ABI, encode_abi
     produceert geldige hex-data, payable-waarde-detectie werkt correct
     in beide token-posities.

**Nog open**: de decimalen-vraag voor `swap_executor_v2.py` (18 vs. 8
decimalen voor de WHBAR-kant van `amountIn`) blijft onbeslist -- de
docs bevestigen "amountIn in token's smallest unit" maar niet expliciet
WHBAR's eigen decimals()-waarde. Kan pas empirisch getest worden zodra
er een bestaande pool is (bv. WHBAR/SAUCE) om een quote tegen te doen.

## KRITIEKE FIX 2: close_position() unwrapte nooit WHBAR (23 aug 2026)

Uit de "Decreasing liquidity (V2)"-docs: `decreaseLiquidity` + `collect`
+ `unwrapWHBAR` horen in EEN multicall. Onze vorige `close_position()`
deed decrease en collect als TWEE losse transacties, en riep
`unwrapWHBAR` NOOIT aan.

**Waarom dit ernstig is**: zonder `unwrapWHBAR` blijft het opgehaalde
bedrag steken als WHBAR-ERC20-token, niet als native HBAR. Dit zou
NABOUW-FIX 4 van eerder vandaag (balans-gebaseerde swap-bedragen via
`_get_swappable_hbar_balance()`, die specifiek de NATIVE HBAR-balans
checkt) stilzwijgend hebben ondermijnd -- na het sluiten van een
LP-positie zou die functie altijd 0 HBAR zien, ook al staat de waarde
er wel degelijk (alleen vast als WHBAR).

Opgelost: `close_position()` bundelt nu `decreaseLiquidity` + `collect`
+ (indien WHBAR betrokken is) `unwrapWHBAR` in EEN multicall, consistent
met `open_position()`'s multicall-patroon van de vorige fix. `unwrapWHBAR`
toegevoegd aan het ABI. Getest: correcte WHBAR-detectie in alle drie de
scenario's (WHBAR als token0, als token1, geen WHBAR betrokken).

## KRITIEKE FIX 3: mint-fee ontbrak, en bijna een nieuwe decimalen-bug (23 aug 2026)

Uit "Liquidity position fee (V2)": er is een APARTE HBAR-fee bovenop de
token-bedragen zelf, opgevraagd via `Factory.mintFee()` (in tinycent
US) en omgerekend naar tinybar via de mirror-node exchange-rate-API
(`/api/v1/network/exchangerate`). Deze fee ontbrak volledig in onze
`payable_value`-berekening.

**Bijvangst tijdens het implementeren**: bij het toevoegen van deze fee
werd duidelijk dat de BESTAANDE `payable_value`-berekening (uit de
vorige fix) zelf een decimalen-fout bevatte -- `amount0_desired`/
`amount1_desired` staan in WHBAR's EIGEN 8-decimalen-termen (correct
voor het `mint()`-structveld), maar `msg.value` wordt door de EVM-relay
geinterpreteerd in de 18-decimalen-wei-conventie. Die twee werden
zonder omrekening gelijkgesteld -- exact dezelfde bug-categorie als
eerder vandaag, deze keer bijna zelf geintroduceerd tijdens het fixen
van iets anders.

Opgelost:
- `NETWORK_SETTINGS` in `config.py` heeft nu `mirror_node_url` per
  netwerk (bevestigd tegen de officiele docs).
- `LpPositionConfig` heeft nieuwe velden `factory_address` en
  `mirror_node_url`.
- `LpManager._get_mint_fee_tinybar()`: vraagt `Factory.mintFee()` op,
  rekent om via de mirror-node-koers.
- `open_position()`'s `payable_value` corrigeert nu expliciet van
  WHBAR's 8-decimalen-termen naar de 18-decimalen-wei-conventie, en
  telt de mint-fee (ook omgerekend) erbij op.
- `regime_orchestrator.py`: geeft `factory_address`/`mirror_node_url`
  door.
- Getest: 1 WHBAR (8-dec) rekent correct om naar 1 HBAR in wei-termen
  (10^18), en de tinycent->tinybar->wei-keten volgt de gedocumenteerde
  formule correct.

## KRITIEKE FIX 4: swap_executor_v2.py miste ook unwrapWHBAR (23 aug 2026)

## DEFINITIEVE CORRECTIE: SwapRouter's unwrapWHBAR werkt niet zoals gedacht (24 aug 2026)

De fixes van 23 augustus (multicall + `unwrapWHBAR` op de SwapRouter/
PositionManager zelf) bleken bij een ECHTE, live test op testnet NIET te
werken -- empirisch bevestigd via twee onafhankelijke swaps (HBAR->SAUCE
werkte prima, maar de omgekeerde richting SAUCE->HBAR liet het bedrag
STEKEN als WHBAR-ERC20-token, ook na een poging met `recipient`=router-
adres in plaats van gebruikersadres).

**Grondoorzaak, definitief vastgesteld**: de SwapRouter's/PositionManager's
eigen `unwrapWHBAR()` unwrapt alleen WHBAR dat het CONTRACT ZELF
binnen dezelfde transactie vasthoudt -- niet WHBAR dat al in de
gebruikers-wallet zit uit een eerdere/losse actie. Dit hadden we nooit
kunnen ontdekken zonder een echte test, want de transactie meldt
gewoon "success" terwijl het feitelijk niets doet.

**De WERKELIJK juiste route**, gevonden via de officiele
`developers/whbar/unwrap-whbar-for-hbar`-documentatie: een APART
contract, `WhbarHelper` (testnet `0.0.5286055`, mainnet `0.0.5808826`),
met een eigen functie `unwrapWhbar(uint256 wad)` (let op: kleine 'w',
andere naam dan de kapotte SwapRouter-variant). Dit contract haalt de
WHBAR ACTIEF op uit de wallet via `safeTransferFrom()`, wat een
voorafgaande `approve()` vereist -- en unwrapt die dan naar native HBAR.

Empirisch bevestigd: het gestrande bedrag (0,34747 WHBAR, opgebouwd uit
twee eerdere mislukte pogingen) is via deze route succesvol teruggehaald.

**Beide bestanden definitief herschreven**:
- `swap_executor_v2.py`: `swap_usdc_to_hbar()` is nu een 2-3-staps-
  proces (swap naar eigen wallet, dan approve+unwrapWhbar via
  WhbarHelper) i.p.v. een enkele multicall.
- `lp_manager.py`: `close_position()` idem -- de kapotte multicall-
  unwrapWHBAR-stap is verwijderd, vervangen door dezelfde WhbarHelper-
  route na collect().
- `config.py`: `whbar_helper`-adressen toegevoegd voor beide netwerken,
  `ResolvedAddresses` uitgebreid.

**Les voor de rest van het project**: dit is de zoveelste keer dat een
"logische aanname op basis van documentatie-patronen" (hier: "vast
patroon herhalen op een ander contract") bij een echte test toch bleek
te kloppen -- niet altijd, dus. Alles wat ooit met echt geld gaat
werken, moet minstens een keer empirisch getest zijn, ongeacht hoe
overtuigend de documentatie-analyse vooraf leek.

Zelfde patroon als KRITIEKE FIX 2 (lp_manager.py), nu gevonden in
`swap_usdc_to_hbar()`: geen `unwrapWHBAR`-stap na de swap, dus het
resultaat zou steken blijven als WHBAR-ERC20-token i.p.v. native HBAR.

**Ook vastgelegd, NIET blind gefixt**: de officiele "Swap tokens for
tokens"-docs demonstreren `exactInput(bytes path, ...)` i.p.v. onze
`exactInputSingle(tuple params)` -- dat is een fundamenteel andere
aanroepvorm. `exactInputSingle` bestaat vermoedelijk ook op het
contract (standaard bij Uniswap V3-forks), maar dit is NIET empirisch
geverifieerd tegen het daadwerkelijke gedrag. Bewust geen gok hier --
expliciet gedocumenteerd in de code zelf als open vraag, te testen
zodra er een bestaande pool is.

**Ook ontdekt**: de output-token moet vooraf geassocieerd zijn bij de
ontvanger, anders `TOKEN_NOT_ASSOCIATED_TO_ACCOUNT`.

Opgelost: `swap_usdc_to_hbar()` bundelt nu `exactInputSingle` +
`unwrapWHBAR` via `multicall`, consistent met het patroon uit
`lp_manager.py`. Getest: multicall/unwrapWHBAR correct herkend en
encodeerbaar op de router.

## Bijgewerkte lijst met vereiste token-associaties

Uit de documentatie-ronde van vandaag blijkt dit er MEER te zijn dan de
oorspronkelijke ene "USDC-associatie"-blokkade:
1. USDC (of het uiteindelijk gekozen alternatief token)
2. WHBAR (bevestigd: `TOKEN_NOT_ASSOCIATED_TO_ACCOUNT` zonder dit)
3. SaucerSwapV2 LP-NFT-token (mainnet `0.0.4054027`, testnet `0.0.1310436`)
4. Elk ander output-token van een swap (algemene regel)

Dit moet allemaal geverifieerd/geregeld worden voordat er ooit uit
DRY_RUN gegaan wordt -- een uitbreiding van de oorspronkelijke blokkade #3.

## DECIMALEN-VRAAG DEFINITIEF OPGELOST (23 aug 2026)

Empirisch getest tegen de echte, bevestigde WHBAR/SAUCE-pool
(contractId 0.0.2661057, fee=3000, liquidity>0, via
test-api.saucerswap.finance ontdekt): een quote met WHBAR in zijn EIGEN
8-decimalen-conventie gaf 57,22 SAUCE voor 1 WHBAR, tegenover een
verwachte ~57,49 (uit de API's priceUsd-velden) -- een verschil van
amper 0,5%, volledig verklaarbaar door normale prijsimpact. Dit
bevestigt: WHBAR's eigen 8 decimalen is de juiste conventie voor het
`amountIn`/`amountOutMinimum`-swap-parameter, NIET de 18-decimalen-
wei-conventie die `swap_executor_v2.py` tot nu toe overal gebruikte.

**Belangrijke nuance, ontdekt tijdens het fixen**: `amountIn` (het
swap-parameter) en `msg.value` (de payable-waarde die daadwerkelijk
verstuurd wordt) staan in TWEE VERSCHILLENDE conventies -- WHBAR's 8
decimalen voor het eerste, de EVM-relay's 18-decimalen-wei-conventie
voor het tweede (native HBAR-representatie). Voorheen werd dezelfde
waarde voor beide hergebruikt in `swap_hbar_to_usdc()`, wat een factor
10^10-mismatch veroorzaakte.

Opgelost: `SwapConfigV2` heeft een nieuw `whbar_decimals=8`-veld.
`quote_hbar_to_usdc()`, `quote_usdc_to_hbar()`, `swap_hbar_to_usdc()`,
en `swap_usdc_to_hbar()` gebruiken nu allemaal consequent WHBAR's eigen
8-decimalen-conventie voor swap-parameters, met `msg.value` apart
berekend in de 18-decimalen-wei-conventie. Getest: het verschil tussen
de twee conventies is exact een factor 10^10, zoals verwacht.

Dit is de laatste van de vandaag gevonden decimalen-gerelateerde
problemen -- de belangrijkste onzekerheid die de hele dag openstond is
nu empirisch, niet alleen theoretisch, bevestigd.

## Eerste live testnet-transacties: gedeeltelijk gelukt (23 aug 2026)

Na de decimalen-fix zijn we overgegaan naar de daadwerkelijke, nog
openstaande blokkade: token-associatie. Bevindingen:

1. **Bot-account bestond nog niet on-chain** (0 HBAR, 404 bij de
   mirror-node) -- opgelost door 10 testnet-HBAR aan te vragen via
   portal.hedera.com/faucet. Account-ID: `0.0.10194038`.
2. **Gas-prijs was verouderd**: onze hardcoded default (500 Gwei) lag
   onder het toen geldende minimum (1110 Gwei) -- opgelost door de
   gas-prijs dynamisch op te vragen (`w3.eth.gas_price`) i.p.v. een
   vaste waarde, met 20% marge.
3. **Gas-limiet te laag geschat**: meerdere hardcoded pogingen
   (800K, 2M) faalden op `INSUFFICIENT_GAS`, telkens exact op de
   limiet. Uiteindelijk opgelost door `build_and_send_transaction()`
   uit te breiden met dynamische gas-schatting via `estimate_gas()`
   (50% veiligheidsmarge) i.p.v. blijven gokken met hardcoded getallen.
4. **WHBAR succesvol geassocieerd** via de enkelvoudige `associateToken()`
   HTS-precompile-call (5.000.000 gas, later bevestigd: de dynamische
   schatting komt uit op ~1,58 miljoen geschat, 2,37 miljoen met marge --
   ruim voldoende).
5. **SAUCE + LP-NFT nog NIET geassocieerd**: de poging faalde op
   "Insufficient funds for transfer" -- niet een bug, maar simpelweg de
   testnet-HBAR-balans op (2,02 HBAR resterend van de oorspronkelijke
   10, de rest opgegaan aan de meerdere mislukte pogingen die ONDANKS
   het falen alsnog gas-kosten in rekening brachten).
6. **Faucet-blokkade**: de Hedera-faucet hanteert een 24-uurs-cooldown
   per adres. Bot-account `0x293ba5c20033400807217980E796A6C2abf70367`
   (Hedera-ID `0.0.10194038`) kan pas over 24 uur opnieuw testnet-HBAR
   aanvragen.

**Openstaand voor de volgende sessie**: zodra er meer testnet-HBAR
beschikbaar is, `associate_required_tokens.py` opnieuw draaien (nu met
dynamische gas-schatting, zou moeten werken) voor SAUCE + LP-NFT.
Daarna: `verify_token_associations.py` ter bevestiging, en dan pas de
eerste daadwerkelijke swap/LP-test op de bevestigde WHBAR/SAUCE-pool.

## Fase 2 (testnet-maand) — bevindingen onderweg (23 aug 2026)

- **Sentiment-venster verruimd** van 1 naar 4 uur (zowel trading- als
  LP-loop) -- bij een gemeten frequentie van ~0,12 BTC- en ~0,17
  HBAR-items per uur was 1 uur te smal, `sentiment_log` bleef leeg na
  15 uur draaien terwijl de bot verder foutloos liep. Dedup via
  `risk_manager` voorkomt dat een breder venster tot dubbele verwerking
  leidt.
- **Junk-filter toegevoegd aan `rss_news_client.py`**: automatisch
  gegenereerde valuta-omreken-pagina's (bv. "Convert 10 HBAR to OMR -
  Bybit") glipten door het keyword-filter heen omdat ze toevallig
  "HBAR" bevatten. `JUNK_TITLE_PATTERNS` sluit deze nu uit (17 -> 6
  items in een test-run, allemaal daadwerkelijk relevant). **Kanttekening**:
  dit was ook actief tijdens de Fase 1-backtest van 22 aug -- een deel
  van de 57 HBAR-backtest-items was mogelijk zulke junk-pagina's, wat de
  eerdere backtest-cijfers enigszins kan hebben vertekend. Overweeg de
  backtest later opnieuw te draaien met deze fix erin.

## Gap-analyse (22 aug 2026) — wat nog niet is afgedekt

Kritisch doorlopen op basis van wat er nu staat, los van de losse
openstaande modules hierboven.

### Blokkerend voor live gebruik met echt geld

1. **Geen dedup van nieuwsitems.** `cryptopanic_client.py` en
   `llm_sentiment_engine.py` houden niet bij welke headlines al
   verwerkt zijn. Bij elke poll-cyclus kan hetzelfde oude nieuws
   opnieuw een signaal triggeren -> risico op dubbele trades op
   basis van hetzelfde bericht. Nodig: een `processed_news_ids`-set
   (Postgres of in-memory), te bouwen als onderdeel van
   `main_orchestrator.py`.
2. **Geen cooldown-periode na een trade.** Vroeg in het project
   genoemd als parameter (`cooldown_period`), maar nooit daadwerkelijk
   gebouwd in `strategy_engine.py`. Zonder dit kan de bot binnen
   enkele minuten meerdere keren tegengesteld handelen op ruis rond
   hetzelfde nieuwsevent (whipsaw).
3. **Geen kapitaal-boekhouding tussen LP-positie en swap-positie.**
   `position_planner.py` en `lp_manager.py` gaan er allebei impliciet
   van uit dat het volledige `total_capital_usdc` (€2000) beschikbaar
   is. Als er tegelijk een LP-positie open staat én een swap-positie,
   kan de bot in theorie meer inzetten dan er daadwerkelijk beschikbaar
   is. Dit hoort een kernverantwoordelijkheid van `risk_manager.py`
   te worden: bijhouden hoeveel kapitaal waar vastzit.
4. **Geen nonce-locking tussen losgekoppelde subprocessen.**
   `execute_hbar_swap_standalone.py` haalt de nonce op via
   `get_transaction_count()`. Als er per ongeluk twee subprocessen
   near-simultaan draaien (bv. een swap én een LP-rebalance), kunnen
   ze dezelfde nonce grijpen en faalt een van de twee transacties.
   Nodig: een simpel lock-bestand of een sequentiële job-queue in
   `main_orchestrator.py` i.p.v. losse fire-and-forget subprocessen.

~~5. Geen backtesting-pipeline~~ — **AFGEVINKT (22 aug 2026)**:
`backtest_pipeline.py` is gebouwd, met `get_price_strictly_at_or_before()`
die actief een `LookaheadBiasError` opgooit bij data uit de toekomst en
te oude candles overslaat. Nog wel nodig: een echte historische
nieuws-dataset en Binance-koersdata om de pipeline te vullen — de
mechaniek staat, de data erin nog niet.

### Belangrijk, maar niet direct blokkerend

6. **Geen retry/backoff-logica** in `cryptopanic_client.py`,
   `coingecko_client.py`, of `llm_sentiment_engine.py`. Eén timeout of
   rate-limit-error laat de huidige poll-cyclus gewoon falen i.p.v.
   netjes opnieuw proberen.
7. **Geen timeout op de Claude-API-call** in `llm_sentiment_engine.py`
   -- een hangende call zou de hele orchestrator-cyclus kunnen
   blokkeren als hier geen `timeout`-parameter aan wordt toegevoegd.
8. **CryptoPanic's gratis tier is zeer beperkt** (5 requests/minuut,
   zie het Gemini-kostenoverzicht) -- bij actief pollen loop je hier
   waarschijnlijk snel tegenaan. Nog niet besproken welk betaald plan
   je wilt gebruiken.
9. **Geen liveness-/heartbeat-melding.** `restart: always` in Docker
   vangt een crash op, maar als de orchestrator zelf blijft hangen
   (geen crash, wel geen voortgang) merk je dat nu niet. Een simpele
   "bot is nog actief"-melding elke paar uur via `telegram_notify.py`
   zou dit afdekken.

### Nice-to-have, niet urgent

10. **Geen liquiditeitsdiepte-check** voor het testnet-USDC-token (we
    zagen eerder een total supply van slechts ~10.000 tokens) --
    grote orders relatief tot een dunne pool geven flinke slippage.
    Voor testnet acceptabel, voor mainnet de moeite van het checken
    waard via `getAmountsOut`/`quoteExactInputSingle` vóór het
    versturen van een trade.
