"""
regime_orchestrator.py

Vervangt TradingOrchestrator + LpOrchestrator voor het SAMENGEVOEGDE
kapitaal (EUR 2.000) met een alles-of-niets regime-schakelaar:

- LP_MODE (rustig nieuws): volledige kapitaal in de HBAR/USDC V2-pool
- BULLISH_REFLEX (groot positief nieuws): pool leeghalen, alles naar HBAR
- BEARISH_REFLEX (groot negatief nieuws): pool leeghalen, alles naar USDC

Trigger: dezelfde vaste 40/60-weging als safety_override.py
(compute_fixed_combined_score), nu SYMMETRISCH toegepast -- niet alleen
als paniek-vangnet (alleen SELL forceren), maar ook als bullish-reflex
(BUY forceren). Dat is een bewuste afwijking van het eerdere principe
"een vangnet forceert nooit een koop" -- hier is het geen vangnet, maar
de kernstrategie zelf, expliciet zo gewenst.

Winst nemen uit de bullish-reflex: TrailingStopTracker bepaalt wanneer
de candle voorbij zijn piek is -- zelfde mechanisme als bij reguliere
directionele trades.

BELANGRIJK: dit maakt TradingOrchestrator's graduele BUY/SELL-logica
overbodig voor DIT kapitaal -- die modules blijven bestaan, maar worden
hier niet gebruikt. Zie PLAN.md.
"""

import asyncio
import json
import os
import time
import subprocess
from enum import Enum
from typing import Optional

from rss_news_client import RssNewsClient
from llm_sentiment_engine import LlmSentimentEngine
from geckoterminal_client import GeckoTerminalClient
from safety_override import compute_fixed_combined_score
from position_planner import TrailingStopTracker
from lp_manager import LpManager, LpPositionConfig
from hedera_rpc_client import HederaRpcClient, NetworkConfig
import telegram_notify
from config import (
    HEDERA_NETWORK, NETWORK_SETTINGS,
    resolve_testnet_addresses, resolve_mainnet_addresses,
    resolve_testnet_v2_addresses, resolve_mainnet_v2_addresses,
)


POLL_INTERVAL_SECONDS = 60
SENTIMENT_REFRESH_SECONDS = 5 * 60
REGIME_THRESHOLD = 0.4

DRY_RUN = os.environ.get("DRY_RUN", "true").lower() == "true"


class Regime(Enum):
    LP_MODE = "lp_mode"
    BULLISH_REFLEX = "bullish_reflex"
    BEARISH_REFLEX = "bearish_reflex"


class RegimeOrchestrator:
    def __init__(self, db):
        self.db = db
        self.rss_news = RssNewsClient()
        self.llm = LlmSentimentEngine()
        self.geckoterminal = GeckoTerminalClient()

        self.total_capital_usdc = float(os.environ.get("REGIME_TOTAL_CAPITAL_USDC", "2000"))
        self.current_regime = Regime.LP_MODE
        self.trailing_tracker: Optional[TrailingStopTracker] = None

        self._cached_btc_score = 0.0
        self._cached_hbar_score = 0.0
        self._last_sentiment_refresh = 0.0
        self._processed_news_ids: set = set()

        # Cooldown tegen flapping: als combined_score rond de drempel
        # schommelt, mag de bot niet elke minuut heen-en-weer schakelen
        # (elke overgang kost swap-fees/slippage). Winst-name via de
        # trailing-stop tijdens BULLISH_REFLEX is hiervan uitgezonderd --
        # dat moet altijd direct kunnen, ongeacht de cooldown.
        self.regime_cooldown_seconds = float(os.environ.get("REGIME_COOLDOWN_SECONDS", str(30 * 60)))
        self._last_transition_at = 0.0

        private_key = os.environ.get("HEDERA_BOT_PRIVATE_KEY", "")
        settings = NETWORK_SETTINGS[HEDERA_NETWORK]
        network = NetworkConfig(rpc_url=settings["rpc_url"], chain_id=settings["chain_id"])
        self.rpc_client = HederaRpcClient(network, private_key) if private_key else None
        self.lp_manager: Optional[LpManager] = None
        self._usdc_decimals = 6  # default, wordt overschreven in _setup_lp_manager indien beschikbaar
        self._hbar_decimals = 8
        if self.rpc_client:
            self._setup_lp_manager()

    def _setup_lp_manager(self):
        self._usdc_decimals = 6  # veilige default, wordt hieronder overschreven
        self._hbar_decimals = 8

        try:
            if HEDERA_NETWORK == "testnet":
                base = resolve_testnet_addresses()
                v2 = resolve_testnet_v2_addresses()
            else:
                base = resolve_mainnet_addresses()
                v2 = resolve_mainnet_v2_addresses()

            self._usdc_decimals = base.usdc_decimals  # 18 op testnet-testtoken, 6 op mainnet

            whbar_addr, usdc_addr = base.whbar_token, base.usdc
            if int(whbar_addr, 16) < int(usdc_addr, 16):
                token0, token1 = whbar_addr, usdc_addr
                t0_dec, t1_dec = self._hbar_decimals, self._usdc_decimals
            else:
                token0, token1 = usdc_addr, whbar_addr
                t0_dec, t1_dec = self._usdc_decimals, self._hbar_decimals

            lp_config = LpPositionConfig(
                position_manager_address=v2.position_manager,
                token0=token0, token1=token1,
                whbar_address=whbar_addr,
                whbar_helper_address=base.whbar_helper,
                factory_address=v2.factory,
                mirror_node_url=NETWORK_SETTINGS[HEDERA_NETWORK]["mirror_node_url"],
                fee_tier=int(os.environ.get("LP_FEE_TIER", "3000")),
                token0_decimals=t0_dec, token1_decimals=t1_dec,
            )
            self.lp_manager = LpManager(self.rpc_client, lp_config)
        except ValueError as e:
            print(f"[regime] lp_manager NIET gekoppeld -- {e}")

    async def run_forever(self):
        while True:
            try:
                await self._cycle()
            except Exception as e:
                import traceback
                print(f"FOUT in regime_loop: {e}")
                traceback.print_exc()
                telegram_notify.report_error("regime_loop", str(e))
            await asyncio.sleep(POLL_INTERVAL_SECONDS)

    async def _refresh_sentiment_if_due(self):
        if (time.time() - self._last_sentiment_refresh) < SENTIMENT_REFRESH_SECONDS:
            return

        for asset in ("BTC", "HBAR"):
            items = self.rss_news.fetch_news(asset, max_age_hours=4.0)
            new_items = [i for i in items if i.id not in self._processed_news_ids]
            if not new_items:
                continue

            results = [self.llm.analyze_headline(asset, i.title) for i in new_items]
            timestamps = [i.published_at for i in new_items]
            score = LlmSentimentEngine.aggregate_with_decay(results, timestamps)

            # KRITIEK: elke losse headline-score loggen naar sentiment_log --
            # zonder dit heeft recalibrate_from_live_history.py (de nachtelijke
            # zelf-herkalibratie) niets meer om uit te putten, aangezien
            # TradingOrchestrator (die dit voorheen deed) niet meer draait.
            for item, result in zip(new_items, results):
                await self.db.log_sentiment(
                    asset=asset, headline=item.title,
                    sentiment_score=result.sentiment_score,
                    confidence=result.confidence,
                    is_idiosyncratic=result.is_idiosyncratic,
                    rationale=result.rationale, source="llm",
                )

            if asset == "BTC":
                self._cached_btc_score = score
            else:
                self._cached_hbar_score = score

            for i in new_items:
                self._processed_news_ids.add(i.id)

        self._last_sentiment_refresh = time.time()

    def _determine_target_regime(self, combined_score: float) -> Regime:
        if combined_score >= REGIME_THRESHOLD:
            return Regime.BULLISH_REFLEX
        elif combined_score <= -REGIME_THRESHOLD:
            return Regime.BEARISH_REFLEX
        return Regime.LP_MODE

    async def _cycle(self):
        await self._refresh_sentiment_if_due()
        combined_score = compute_fixed_combined_score(self._cached_btc_score, self._cached_hbar_score)

        try:
            current_price = self.geckoterminal.get_pool_snapshot().price_usd
        except Exception as e:
            telegram_notify.report_error("regime_loop: prijs ophalen", str(e))
            return

        target_regime = self._determine_target_regime(combined_score)
        is_profit_take = False

        if self.current_regime == Regime.BULLISH_REFLEX and self.trailing_tracker:
            stop_price = self.trailing_tracker.update(current_price)
            if current_price <= stop_price:
                print(f"[regime] Trailing-stop getriggerd tijdens BULLISH_REFLEX "
                      f"(prijs={current_price:.5f} <= stop={stop_price:.5f}) -- winst nemen.")
                target_regime = Regime.LP_MODE
                is_profit_take = True

        if target_regime == self.current_regime:
            print(f"[regime] Blijft in {self.current_regime.value} "
                  f"(combined_score={combined_score:+.2f}, prijs={current_price:.5f})")
            return

        # Cooldown tegen flapping -- winst-name via de trailing-stop is
        # hiervan uitgezonderd, die moet altijd direct kunnen.
        seconds_since_last = time.time() - self._last_transition_at
        if not is_profit_take and seconds_since_last < self.regime_cooldown_seconds:
            remaining_min = (self.regime_cooldown_seconds - seconds_since_last) / 60
            print(f"[regime] Overgang naar {target_regime.value} uitgesteld -- "
                  f"cooldown actief, nog {remaining_min:.1f} min.")
            return

        print(f"[regime] OVERGANG: {self.current_regime.value} -> {target_regime.value} "
              f"(combined_score={combined_score:+.2f})")

        await self.db.log_strategy_signal(
            direction=target_regime.value, confidence=abs(combined_score),
            position_fraction=1.0, btc_score=self._cached_btc_score,
            hbar_score=self._cached_hbar_score,
            panic_override_triggered=(target_regime == Regime.BEARISH_REFLEX),
            reasoning=f"Regime-overgang {self.current_regime.value} -> {target_regime.value}"
                      f"{' (winst-name)' if is_profit_take else ''}",
        )

        if DRY_RUN:
            print(f"[DRY RUN] Zou overgaan van {self.current_regime.value} naar {target_regime.value}")
            if target_regime == Regime.BULLISH_REFLEX:
                self.trailing_tracker = TrailingStopTracker(
                    entry_price=current_price, trailing_distance_pct=0.05,
                    initial_stop_loss=current_price * 0.95,
                )
            self.current_regime = target_regime
            self._last_transition_at = time.time()
            return

        transition_succeeded = await self._execute_transition(target_regime, current_price)
        self._last_transition_at = time.time()

        if transition_succeeded:
            self.current_regime = target_regime
        # Bij falen: current_regime blijft bewust ongewijzigd (de vorige,
        # bekende staat) -- de foutmelding is al verstuurd in
        # _execute_transition. Handmatige controle is dan nodig voordat
        # de bot hier weer op vertrouwt.

    # Hedera's transactiekosten zijn vastgesteld in USD-termen (fee-schedule),
    # maar worden betaald in HBAR -- een vaste HBAR-reserve zou dus fout zijn
    # in twee richtingen als de HBAR-prijs beweegt: te veel kapitaal
    # inactief bij een hoge prijs, te weinig dekking bij een lage prijs.
    # $2 dekt ruimschoots meerdere toekomstige transacties, gezien Hedera's
    # kosten doorgaans een fractie van een cent tot een paar cent per tx zijn.
    GAS_RESERVE_USD = 2.0
    # Ondergrens (op verzoek, 23 aug 2026): ongeacht de prijs nooit minder
    # dan 10 HBAR reserveren -- bij een hoge HBAR-prijs zou de USD-som
    # anders een te kleine reserve opleveren.
    MIN_GAS_RESERVE_HBAR = 10.0

    def _get_swappable_hbar_balance(self, current_price: float) -> float:
        """
        Vraagt de WERKELIJKE on-chain HBAR-balans op i.p.v. te herberekenen
        vanuit total_capital_usdc/current_price -- dat laatste zou bij een
        koersstijging tijdens BULLISH_REFLEX stelselmatig te weinig HBAR
        teruggeven (de koerswinst wordt dan nooit verzilverd), en na het
        sluiten van een LP-positie klopt de aanname van "100% in één token"
        sowieso niet meer (er komt een mix van HBAR+USDC terug).

        De gas-reserve is het GROOTSTE van (a) de USD-gebaseerde berekening
        (schaalt correct mee met de prijs) en (b) een vaste ondergrens van
        MIN_GAS_RESERVE_HBAR, zodat de reserve bij een hoge HBAR-prijs nooit
        te klein wordt.
        """
        if not self.rpc_client:
            return 0.0
        try:
            balance = self.rpc_client.get_hbar_balance()
            usd_based_reserve = self.GAS_RESERVE_USD / current_price if current_price > 0 else 0.0
            gas_reserve_hbar = max(usd_based_reserve, self.MIN_GAS_RESERVE_HBAR)
            return max(0.0, float(balance) - gas_reserve_hbar)
        except Exception as e:
            telegram_notify.report_error("regime_loop: HBAR-balans opvragen", str(e))
            return 0.0

    def _get_swappable_usdc_balance(self) -> float:
        """Zelfde principe als hierboven, voor USDC."""
        if not self.rpc_client:
            return 0.0
        try:
            if HEDERA_NETWORK == "testnet":
                base = resolve_testnet_addresses()
            else:
                base = resolve_mainnet_addresses()
            from swap_executor import ERC20_ABI
            balance = self.rpc_client.get_token_balance(
                base.usdc, ERC20_ABI, decimals=base.usdc_decimals
            )
            return max(0.0, float(balance))
        except Exception as e:
            telegram_notify.report_error("regime_loop: USDC-balans opvragen", str(e))
            return 0.0

    async def _run_swap_and_log(self, direction: str, amount: float) -> bool:
        """Voert een swap uit en logt het resultaat naar Postgres. Geeft True terug bij succes."""
        result = subprocess.run(
            ["python3", "execute_hbar_swap_standalone.py",
             "--direction", direction, "--amount", str(amount),
             "--network", HEDERA_NETWORK, "--engine", "v2"],
            capture_output=True, text=True,
        )
        status = "success" if result.returncode == 0 else "failed"

        # Gestructureerde output parsen (23 aug 2026 toegevoegd aan
        # execute_hbar_swap_standalone.py) -- zonder dit werden tx_hash en
        # estimated_amount_out altijd als None gelogd, wat elke vorm van
        # winst/verlies-analyse achteraf onmogelijk maakte.
        tx_hash, estimated_amount_out = None, None
        try:
            last_line = result.stdout.strip().splitlines()[-1]
            parsed = json.loads(last_line)
            tx_hash = parsed.get("tx_hash")
            estimated_amount_out = parsed.get("estimated_amount_out")
        except (IndexError, json.JSONDecodeError):
            pass  # subprocess gaf geen geldige JSON terug -- blijft None, geen crash

        await self.db.log_trade(
            direction=direction, engine="v2", network=HEDERA_NETWORK,
            amount_in=amount, estimated_amount_out=estimated_amount_out,
            actual_amount_out=None,  # SaucerSwap's exactInputSingle-return-waarde
                                       # wordt nog niet teruggegeven door de subprocess-
                                       # aanroep -- estimated_amount_out is het beste
                                       # wat we nu hebben, nog geen exacte uitkomst.
            tx_hash=tx_hash, status=status,
            strategy_signal_id=None,
        )

        if status == "failed":
            telegram_notify.report_error(
                "regime_loop: swap", f"Swap {direction} ({amount:.4f}) mislukt: {result.stderr[:200]}"
            )

        return status == "success"

    async def _execute_transition(self, target_regime: Regime, current_price: float) -> bool:
        """
        Geeft True terug als de overgang volledig is gelukt, False als er
        ergens een swap is mislukt. De aanroeper mag self.current_regime
        ALLEEN bijwerken bij True -- anders raakt de interne staat
        losgezongen van de werkelijke, on-chain positie.
        """
        # Expliciete guard: zonder rpc_client geven de balans-functies 0.0
        # terug, wat de amount>0-checks verderop stil zou laten slagen
        # (geen swap nodig bij bedrag 0) -- zonder deze check zou de bot
        # zichzelf dan valselijk als "overgang geslaagd" registreren,
        # inclusief een misleidende Telegram-bevestiging, terwijl er
        # helemaal geen wallet is aangesloten en er dus niets is gebeurd.
        if not self.rpc_client:
            telegram_notify.report_error(
                "regime_loop",
                f"Overgang naar {target_regime.value} geweigerd -- geen rpc_client "
                f"(HEDERA_BOT_PRIVATE_KEY ontbreekt?) terwijl DRY_RUN=false staat. "
                f"HANDMATIGE CONTROLE VEREIST: de bot kan geen transacties uitvoeren.",
            )
            return False

        all_succeeded = True

        if self.current_regime == Regime.LP_MODE and self.lp_manager and self.lp_manager.state.is_open:
            try:
                self.lp_manager.close_position(self.lp_manager.state.token_id)
                telegram_notify.send_telegram_message("Regime-schakelaar: LP-positie volledig geleegd.")
            except Exception as e:
                all_succeeded = False
                telegram_notify.report_error(
                    "regime_loop: LP-positie sluiten",
                    f"{e} -- HANDMATIGE CONTROLE VEREIST, LP-positie mogelijk nog (deels) open.",
                )

        if target_regime == Regime.BULLISH_REFLEX:
            usdc_to_swap = self._get_swappable_usdc_balance()
            success = True
            if usdc_to_swap > 0:
                success = await self._run_swap_and_log("USDC_TO_HBAR", usdc_to_swap)
            all_succeeded = all_succeeded and success
            if success:
                self.trailing_tracker = TrailingStopTracker(
                    entry_price=current_price, trailing_distance_pct=0.05,
                    initial_stop_loss=current_price * 0.95,
                )
                telegram_notify.send_telegram_message(
                    f"Regime-schakelaar: BULLISH_REFLEX -- {usdc_to_swap:.2f} USDC naar HBAR "
                    f"bij {current_price:.5f}."
                )

        elif target_regime == Regime.BEARISH_REFLEX:
            hbar_to_swap = self._get_swappable_hbar_balance(current_price)
            success = True
            if hbar_to_swap > 0:
                success = await self._run_swap_and_log("HBAR_TO_USDC", hbar_to_swap)
            all_succeeded = all_succeeded and success
            if success:
                self.trailing_tracker = None
                telegram_notify.send_telegram_message(
                    f"Regime-schakelaar: BEARISH_REFLEX -- {hbar_to_swap:.4f} HBAR naar USDC "
                    f"bij {current_price:.5f}."
                )

        elif target_regime == Regime.LP_MODE:
            # Herbalanceren naar ~50/50 op basis van de WERKELIJKE balans,
            # niet een herberekend nominaal bedrag (zie NABOUW-FIX 4).
            if self.current_regime == Regime.BULLISH_REFLEX:
                hbar_balance = self._get_swappable_hbar_balance(current_price)
                half_hbar = hbar_balance / 2
                success = True
                if half_hbar > 0:
                    success = await self._run_swap_and_log("HBAR_TO_USDC", half_hbar)
                all_succeeded = all_succeeded and success
            elif self.current_regime == Regime.BEARISH_REFLEX:
                usdc_balance = self._get_swappable_usdc_balance()
                half_usdc = usdc_balance / 2
                success = True
                if half_usdc > 0:
                    success = await self._run_swap_and_log("USDC_TO_HBAR", half_usdc)
                all_succeeded = all_succeeded and success

            if all_succeeded and self.lp_manager:
                # Balans NA de herbalancerings-swap opvragen, niet vooraf
                # geschat -- dat is de daadwerkelijke inzet voor de LP-positie.
                final_hbar_balance = self._get_swappable_hbar_balance(current_price)
                final_usdc_balance = self._get_swappable_usdc_balance()
                hbar_raw = int(final_hbar_balance * (10 ** self._hbar_decimals))
                usdc_raw = int(final_usdc_balance * (10 ** self._usdc_decimals))
                try:
                    self.lp_manager.open_position(hbar_raw, usdc_raw, current_price)
                    self.trailing_tracker = None
                    telegram_notify.send_telegram_message(
                        f"Regime-schakelaar: terug naar LP_MODE -- {final_hbar_balance:.4f} HBAR "
                        f"+ {final_usdc_balance:.2f} USDC in de pool."
                    )
                except Exception as e:
                    all_succeeded = False
                    telegram_notify.report_error(
                        "regime_loop: LP-positie openen",
                        f"{e} -- herbalancerings-swap is al gebeurd, maar de LP-positie zelf niet "
                        f"geopend. Kapitaal staat nu los in HBAR/USDC. HANDMATIGE CONTROLE VEREIST.",
                    )

        if not all_succeeded:
            telegram_notify.report_error(
                "regime_loop",
                f"Overgang naar {target_regime.value} DEELS OF VOLLEDIG MISLUKT -- "
                f"regime blijft geregistreerd als {self.current_regime.value}, maar de "
                f"werkelijke on-chain positie is mogelijk inconsistent. HANDMATIGE "
                f"CONTROLE VEREIST voordat de bot hier verder op vertrouwt.",
            )

        return all_succeeded
